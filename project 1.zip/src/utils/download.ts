import { Wallpaper } from '../types';

export interface DownloadOptions {
  resolutionLabel: string;
  width?: number;
  height?: number;
}

/**
 * Downloads a wallpaper image to user's device with proper naming
 */
export async function downloadWallpaperFile(
  wallpaper: Wallpaper,
  options?: DownloadOptions
): Promise<boolean> {
  try {
    const filename = `${wallpaper.title.toLowerCase().replace(/[^a-z0-9]/g, '-')}-${options?.resolutionLabel || 'original'}.jpg`;
    
    // For data URI or direct cross-origin images, create anchor
    if (wallpaper.imageUrl.startsWith('data:')) {
      const link = document.createElement('a');
      link.href = wallpaper.imageUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      return true;
    }

    // For external URLs, fetch as blob to enforce clean file download
    try {
      const response = await fetch(wallpaper.imageUrl, { mode: 'cors' });
      if (response.ok) {
        const blob = await response.blob();
        const blobUrl = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = blobUrl;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        setTimeout(() => window.URL.revokeObjectURL(blobUrl), 2000);
        return true;
      }
    } catch {
      // Fallback: direct window link trigger
      const link = document.createElement('a');
      link.href = wallpaper.imageUrl;
      link.target = '_blank';
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      return true;
    }

    return true;
  } catch (error) {
    console.error('Download failed:', error);
    // Final fallback
    window.open(wallpaper.imageUrl, '_blank');
    return false;
  }
}
