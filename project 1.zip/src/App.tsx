/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  Category,
  FilterState,
  ResolutionCategory,
  User,
  Wallpaper,
  WallpaperReport,
} from './types';
import {
  getStoredWallpapers,
  saveWallpapers,
  addWallpaper,
  updateWallpaper,
  deleteWallpaper,
  getStoredCategories,
  saveCategories,
  getStoredFavoriteIds,
  toggleFavoriteId,
  getCurrentUser,
  setCurrentUser,
  getUserRatings,
  setUserRating,
  getStoredReports,
  addReport,
  updateReportStatus,
  getStoredTheme,
  setStoredTheme,
  DEFAULT_USER,
  ADMIN_USER,
} from './services/storage';
import { downloadWallpaperFile } from './utils/download';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { CategoryChips } from './components/CategoryChips';
import { FilterBar } from './components/FilterBar';
import { WallpaperCard } from './components/WallpaperCard';
import { WallpaperModal } from './components/WallpaperModal';
import { AIGeneratorModal } from './components/AIGeneratorModal';
import { FavoritesView } from './components/FavoritesView';
import { AdminDashboard } from './components/AdminDashboard';
import { AuthModal } from './components/AuthModal';
import { UserProfileModal } from './components/UserProfileModal';
import { ReportModal } from './components/ReportModal';
import { InfoModals } from './components/InfoModals';
import { Footer } from './components/Footer';
import { ToastContainer, ToastMessage } from './components/Toast';
import {
  Flame,
  Sparkles,
  Download,
  ArrowRight,
  RefreshCw,
  Search,
  Filter,
} from 'lucide-react';

export default function App() {
  // Theme state
  const [theme, setTheme] = useState<'dark' | 'light'>(getStoredTheme);

  // Sync theme with document class
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    setStoredTheme(theme);
  }, [theme]);

  const handleToggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  // Core Data State
  const [wallpapers, setWallpapers] = useState<Wallpaper[]>(getStoredWallpapers);
  const [categories, setCategories] = useState<Category[]>(getStoredCategories);
  const [favoriteIds, setFavoriteIds] = useState<string[]>(getStoredFavoriteIds);
  const [currentUser, setCurrentUserState] = useState<User | null>(getCurrentUser);
  const [reports, setReports] = useState<WallpaperReport[]>(getStoredReports);
  const [ratings, setRatings] = useState<Record<string, number>>(getUserRatings);

  // Navigation State
  const [currentTab, setCurrentTab] = useState<'home' | 'categories' | 'favorites' | 'admin' | 'ai-studio'>('home');

  // Filter State
  const [filters, setFilters] = useState<FilterState>({
    searchQuery: '',
    category: 'All',
    resolutionCategory: 'All',
    aspectRatio: 'All',
    sortBy: 'trending',
    color: 'All',
  });

  const [layoutMode, setLayoutMode] = useState<'standard' | 'compact'>('standard');
  const [visibleCount, setVisibleCount] = useState<number>(12);

  // Modals State
  const [selectedWallpaper, setSelectedWallpaper] = useState<Wallpaper | null>(null);
  const [wallpaperForReport, setWallpaperForReport] = useState<Wallpaper | null>(null);
  const [isAIStudioOpen, setIsAIStudioOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [infoModalType, setInfoModalType] = useState<'about' | 'contact' | 'privacy' | 'terms' | null>(null);

  // Toast Notifications
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = (type: 'success' | 'error' | 'info', title: string, description?: string) => {
    const newToast: ToastMessage = {
      id: `toast-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      type,
      title,
      description,
    };
    setToasts((prev) => [...prev, newToast]);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Daily Featured Wallpaper Spotlight
  const featuredWallpaper = useMemo(() => {
    return wallpapers.find((w) => w.isFeatured) || wallpapers[0];
  }, [wallpapers]);

  // Favorite Wallpapers List
  const favoriteWallpapers = useMemo(() => {
    return wallpapers.filter((w) => favoriteIds.includes(w.id));
  }, [wallpapers, favoriteIds]);

  // Toggle Favorite
  const handleToggleFavorite = (id: string) => {
    const { favoriteIds: updated, isFavorite } = toggleFavoriteId(id);
    setFavoriteIds(updated);

    // Update wallpaper like count
    setWallpapers((prev) =>
      prev.map((w) => {
        if (w.id === id) {
          const updatedLikes = isFavorite ? w.likes + 1 : Math.max(0, w.likes - 1);
          return { ...w, likes: updatedLikes };
        }
        return w;
      })
    );

    addToast(
      isFavorite ? 'success' : 'info',
      isFavorite ? 'Added to favorites' : 'Removed from favorites'
    );
  };

  // Download Handler
  const handleDownloadWallpaper = async (wallpaper: Wallpaper, resolutionLabel?: string) => {
    await downloadWallpaperFile(wallpaper, {
      resolutionLabel: resolutionLabel || wallpaper.resolutionCategory,
    });

    // Increment downloads count in state & storage
    const updatedWallpapers = wallpapers.map((w) => {
      if (w.id === wallpaper.id) {
        return { ...w, downloads: w.downloads + 1 };
      }
      return w;
    });
    setWallpapers(updatedWallpapers);
    saveWallpapers(updatedWallpapers);

    // Increment current user download count if logged in
    if (currentUser) {
      const updatedUser = {
        ...currentUser,
        downloadsCount: currentUser.downloadsCount + 1,
      };
      setCurrentUserState(updatedUser);
      setCurrentUser(updatedUser);
    }

    addToast('success', `Downloading ${resolutionLabel || '4K Ultra HD'}!`, wallpaper.title);
  };

  // Rating Handler
  const handleRateWallpaper = (wallpaperId: string, rating: number) => {
    setUserRating(wallpaperId, rating);
    setRatings((prev) => ({ ...prev, [wallpaperId]: rating }));

    setWallpapers((prev) =>
      prev.map((w) => {
        if (w.id === wallpaperId) {
          const newRatingsCount = w.ratingsCount + 1;
          const newRating = Number(
            ((w.rating * w.ratingsCount + rating) / newRatingsCount).toFixed(1)
          );
          return { ...w, rating: newRating, ratingsCount: newRatingsCount };
        }
        return w;
      })
    );
  };

  // Report Submission Handler
  const handleSubmitReport = (
    wallpaperId: string,
    wallpaperTitle: string,
    reason: 'copyright' | 'inappropriate' | 'low_quality' | 'broken' | 'other',
    comment: string
  ) => {
    addReport({ wallpaperId, wallpaperTitle, reason, comment });
    setReports(getStoredReports());
  };

  // Resolve Report Handler (Admin)
  const handleResolveReport = (reportId: string, status: 'resolved' | 'dismissed') => {
    const updated = updateReportStatus(reportId, status);
    setReports(updated);
  };

  // Filtered Wallpapers Pipeline
  const filteredWallpapers = useMemo(() => {
    let result = [...wallpapers];

    // Search query filter
    if (filters.searchQuery.trim()) {
      const q = filters.searchQuery.toLowerCase().trim();
      result = result.filter(
        (w) =>
          w.title.toLowerCase().includes(q) ||
          w.category.toLowerCase().includes(q) ||
          w.tags?.some((t) => t.toLowerCase().includes(q)) ||
          w.author.name.toLowerCase().includes(q) ||
          w.resolution.toLowerCase().includes(q)
      );
    }

    // Category filter
    if (filters.category !== 'All') {
      result = result.filter(
        (w) => w.category.toLowerCase() === filters.category.toLowerCase()
      );
    }

    // Resolution filter
    if (filters.resolutionCategory !== 'All') {
      result = result.filter((w) => w.resolutionCategory === filters.resolutionCategory);
    }

    // Aspect Ratio filter
    if (filters.aspectRatio !== 'All') {
      result = result.filter((w) => w.aspectRatio === filters.aspectRatio);
    }

    // Color Tone Filter
    if (filters.color !== 'All') {
      const c = filters.color;
      result = result.filter((w) => {
        if (!w.palette) return true;
        if (c === 'dark') {
          return w.palette.some((hex) => hex.startsWith('#0') || hex.startsWith('#1') || hex.startsWith('#2'));
        }
        if (c === 'blue') {
          return w.palette.some((hex) => hex.includes('3') || hex.includes('F') || hex.toLowerCase().includes('007'));
        }
        return true;
      });
    }

    // Sorting
    if (filters.sortBy === 'trending') {
      result.sort((a, b) => b.likes + b.downloads * 0.5 - (a.likes + a.downloads * 0.5));
    } else if (filters.sortBy === 'popular') {
      result.sort((a, b) => b.views - a.views);
    } else if (filters.sortBy === 'downloads') {
      result.sort((a, b) => b.downloads - a.downloads);
    } else if (filters.sortBy === 'rating') {
      result.sort((a, b) => b.rating - a.rating);
    } else if (filters.sortBy === 'latest') {
      result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    } else if (filters.sortBy === 'title') {
      result.sort((a, b) => a.title.localeCompare(b.title));
    }

    return result;
  }, [wallpapers, filters]);

  // Paginated/Sliced Wallpapers
  const displayedWallpapers = useMemo(() => {
    return filteredWallpapers.slice(0, visibleCount);
  }, [filteredWallpapers, visibleCount]);

  // Similar Wallpapers for selected wallpaper
  const similarWallpapers = useMemo(() => {
    if (!selectedWallpaper) return [];
    return wallpapers
      .filter(
        (w) =>
          w.id !== selectedWallpaper.id &&
          (w.category === selectedWallpaper.category ||
            w.tags.some((t) => selectedWallpaper.tags.includes(t)))
      )
      .slice(0, 4);
  }, [wallpapers, selectedWallpaper]);

  // Add Wallpaper (Admin or AI Studio)
  const handleAddNewWallpaper = (newWp: Wallpaper) => {
    const updated = addWallpaper(newWp);
    setWallpapers(updated);

    // Update category count
    setCategories((prev) =>
      prev.map((c) =>
        c.name.toLowerCase() === newWp.category.toLowerCase()
          ? { ...c, count: c.count + 1 }
          : c
      )
    );
  };

  // Update Wallpaper (Admin)
  const handleUpdateWallpaper = (updatedWp: Wallpaper) => {
    const updated = updateWallpaper(updatedWp);
    setWallpapers(updated);
  };

  // Delete Wallpaper (Admin)
  const handleDeleteWallpaper = (id: string) => {
    const wp = wallpapers.find((w) => w.id === id);
    const updated = deleteWallpaper(id);
    setWallpapers(updated);

    if (wp) {
      setCategories((prev) =>
        prev.map((c) =>
          c.name.toLowerCase() === wp.category.toLowerCase()
            ? { ...c, count: Math.max(0, c.count - 1) }
            : c
        )
      );
    }
  };

  // Category Management
  const handleAddCategory = (newCat: Category) => {
    const updated = [...categories, newCat];
    setCategories(updated);
    saveCategories(updated);
  };

  const handleUpdateCategory = (updatedCat: Category) => {
    const updated = categories.map((c) => (c.id === updatedCat.id ? updatedCat : c));
    setCategories(updated);
    saveCategories(updated);
  };

  const handleDeleteCategory = (id: string) => {
    const updated = categories.filter((c) => c.id !== id);
    setCategories(updated);
    saveCategories(updated);
  };

  // User switch role helper for quick testing
  const handleSwitchUserRole = (newRole: 'user' | 'admin') => {
    if (newRole === 'admin') {
      setCurrentUserState(ADMIN_USER);
      setCurrentUser(ADMIN_USER);
      addToast('info', 'Switched to Admin Role');
    } else {
      setCurrentUserState(DEFAULT_USER);
      setCurrentUser(DEFAULT_USER);
      addToast('info', 'Switched to Member Role');
    }
  };

  return (
    <div className="min-h-screen bg-white dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 flex flex-col font-sans transition-colors selection:bg-indigo-500 selection:text-white">
      {/* Navbar */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={(tab) => {
          if (tab === 'ai-studio') {
            setIsAIStudioOpen(true);
          } else {
            setCurrentTab(tab);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }
        }}
        favoritesCount={favoriteIds.length}
        theme={theme}
        onToggleTheme={handleToggleTheme}
        user={currentUser}
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenProfile={() => setIsProfileOpen(true)}
        onOpenAIStudio={() => setIsAIStudioOpen(true)}
        onLogout={() => {
          setCurrentUserState(null);
          setCurrentUser(null);
          addToast('info', 'Signed out successfully.');
        }}
        searchQuery={filters.searchQuery}
        onSearchChange={(q) => {
          setFilters((prev) => ({ ...prev, searchQuery: q }));
          if (currentTab !== 'home') setCurrentTab('home');
        }}
        onSwitchUserRole={handleSwitchUserRole}
      />

      {/* Main Content Areas based on Tab */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8">
        {/* TAB 1: HOME & EXPLORE */}
        {currentTab === 'home' && (
          <div className="space-y-8">
            {/* Hero Section */}
            <Hero
              featuredWallpaper={featuredWallpaper}
              searchQuery={filters.searchQuery}
              onSearchChange={(q) => setFilters((prev) => ({ ...prev, searchQuery: q }))}
              onOpenDetails={(w) => setSelectedWallpaper(w)}
              onQuickDownload={handleDownloadWallpaper}
              onToggleFavorite={handleToggleFavorite}
              isFavorite={favoriteIds.includes(featuredWallpaper.id)}
              onOpenAIStudio={() => setIsAIStudioOpen(true)}
              onSelectCategory={(cat) => {
                setFilters((prev) => ({ ...prev, category: cat, searchQuery: '' }));
              }}
            />

            {/* Category Quick Chips Carousel */}
            <div className="pt-2">
              <CategoryChips
                categories={categories}
                selectedCategory={filters.category}
                onSelectCategory={(cat) => setFilters((prev) => ({ ...prev, category: cat }))}
                variant="chips"
              />
            </div>

            {/* Quick Preset Collections Banner */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-zinc-200 dark:border-zinc-800">
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                {[
                  { label: '🔥 Trending', sort: 'trending' },
                  { label: '✨ Most Downloaded', sort: 'downloads' },
                  { label: '★ Highest Rated', sort: 'rating' },
                  { label: '🕒 Recently Added', sort: 'latest' },
                ].map((preset) => {
                  const isSelected = filters.sortBy === preset.sort;
                  return (
                    <button
                      key={preset.sort}
                      onClick={() =>
                        setFilters((prev) => ({ ...prev, sortBy: preset.sort as any }))
                      }
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 ${
                        isSelected
                          ? 'bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 shadow-sm'
                          : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white hover:bg-zinc-100 dark:hover:bg-zinc-800'
                      }`}
                    >
                      {preset.label}
                    </button>
                  );
                })}
              </div>

              {/* AI Studio prompt callout banner */}
              <button
                onClick={() => setIsAIStudioOpen(true)}
                className="px-3.5 py-1.5 rounded-xl bg-violet-500/10 hover:bg-violet-500/20 text-violet-600 dark:text-violet-400 border border-violet-500/20 text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Need a custom ratio? Generate with Gemini AI Studio</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            {/* Advanced Filter Bar (Resolution, Aspect Ratio, Color, Layout) */}
            <FilterBar
              filters={filters}
              onFilterChange={(newF) => {
                setFilters(newF);
                setVisibleCount(12);
              }}
              totalResults={filteredWallpapers.length}
              layoutMode={layoutMode}
              onToggleLayout={setLayoutMode}
            />

            {/* Wallpaper Gallery Grid */}
            {displayedWallpapers.length > 0 ? (
              <div
                className={`grid gap-5 ${
                  layoutMode === 'compact'
                    ? 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5'
                    : 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4'
                }`}
              >
                {displayedWallpapers.map((wallpaper) => (
                  <WallpaperCard
                    key={wallpaper.id}
                    wallpaper={wallpaper}
                    isFavorite={favoriteIds.includes(wallpaper.id)}
                    onToggleFavorite={handleToggleFavorite}
                    onOpenDetails={(w) => setSelectedWallpaper(w)}
                    onDownload={handleDownloadWallpaper}
                    layoutMode={layoutMode}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-20 px-4 space-y-4 rounded-3xl bg-zinc-50 dark:bg-zinc-900/50 border border-zinc-200 dark:border-zinc-800">
                <Search className="w-10 h-10 text-zinc-400 mx-auto" />
                <h3 className="text-lg font-bold text-zinc-900 dark:text-white">
                  No wallpapers found matching your filters
                </h3>
                <p className="text-xs text-zinc-500 dark:text-zinc-400 max-w-sm mx-auto">
                  Try clearing some filters, exploring other categories, or generating a custom wallpaper with Gemini AI Studio.
                </p>
                <div className="flex items-center justify-center gap-3 pt-2">
                  <button
                    onClick={() =>
                      setFilters({
                        searchQuery: '',
                        category: 'All',
                        resolutionCategory: 'All',
                        aspectRatio: 'All',
                        sortBy: 'trending',
                        color: 'All',
                      })
                    }
                    className="px-4 py-2 rounded-xl bg-zinc-200 dark:bg-zinc-800 text-xs font-semibold text-zinc-800 dark:text-zinc-200"
                  >
                    Reset All Filters
                  </button>
                  <button
                    onClick={() => setIsAIStudioOpen(true)}
                    className="px-4 py-2 rounded-xl bg-indigo-600 text-xs font-semibold text-white flex items-center gap-1.5 shadow-md"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                    <span>Generate With AI</span>
                  </button>
                </div>
              </div>
            )}

            {/* Load More / Pagination */}
            {displayedWallpapers.length < filteredWallpapers.length && (
              <div className="text-center pt-8 pb-4">
                <button
                  onClick={() => setVisibleCount((prev) => prev + 12)}
                  className="px-6 py-3 rounded-2xl bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-850 dark:hover:bg-zinc-800 text-zinc-900 dark:text-white text-xs sm:text-sm font-bold border border-zinc-200 dark:border-zinc-800 shadow-sm transition-all"
                >
                  Load More Wallpapers ({filteredWallpapers.length - displayedWallpapers.length} remaining)
                </button>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: CATEGORIES VIEW */}
        {currentTab === 'categories' && (
          <CategoryChips
            categories={categories}
            selectedCategory={filters.category}
            onSelectCategory={(cat) => {
              setFilters((prev) => ({ ...prev, category: cat, searchQuery: '' }));
              setCurrentTab('home');
            }}
            variant="grid"
          />
        )}

        {/* TAB 3: FAVORITES VIEW */}
        {currentTab === 'favorites' && (
          <FavoritesView
            favorites={favoriteWallpapers}
            onToggleFavorite={handleToggleFavorite}
            onOpenDetails={(w) => setSelectedWallpaper(w)}
            onDownload={handleDownloadWallpaper}
            onExplore={() => setCurrentTab('home')}
            onClearFavorites={() => {
              if (window.confirm('Clear all your favorites?')) {
                setFavoriteIds([]);
                localStorage.setItem('lumina_favorites_v1', JSON.stringify([]));
                addToast('info', 'All favorites cleared.');
              }
            }}
            onDownloadAllFavorites={() => {
              favoriteWallpapers.forEach((w) => handleDownloadWallpaper(w));
              addToast('success', `Initiating download of ${favoriteWallpapers.length} wallpapers.`);
            }}
          />
        )}

        {/* TAB 4: ADMIN DASHBOARD */}
        {currentTab === 'admin' && (
          <AdminDashboard
            wallpapers={wallpapers}
            categories={categories}
            reports={reports}
            currentUser={currentUser}
            onAddWallpaper={handleAddNewWallpaper}
            onUpdateWallpaper={handleUpdateWallpaper}
            onDeleteWallpaper={handleDeleteWallpaper}
            onAddCategory={handleAddCategory}
            onUpdateCategory={handleUpdateCategory}
            onDeleteCategory={handleDeleteCategory}
            onResolveReport={handleResolveReport}
            onTriggerToast={addToast}
          />
        )}
      </main>

      {/* Footer */}
      <Footer
        onOpenModal={(type) => setInfoModalType(type)}
        onSelectCategory={(cat) => {
          setFilters((prev) => ({ ...prev, category: cat, searchQuery: '' }));
          setCurrentTab('home');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onSelectResolution={(res) => {
          setFilters((prev) => ({ ...prev, resolutionCategory: res as ResolutionCategory }));
          setCurrentTab('home');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenAIStudio={() => setIsAIStudioOpen(true)}
      />

      {/* Wallpaper Details Modal */}
      {selectedWallpaper && (
        <WallpaperModal
          wallpaper={selectedWallpaper}
          onClose={() => setSelectedWallpaper(null)}
          isFavorite={favoriteIds.includes(selectedWallpaper.id)}
          onToggleFavorite={handleToggleFavorite}
          onDownload={handleDownloadWallpaper}
          onRateWallpaper={handleRateWallpaper}
          userRating={ratings[selectedWallpaper.id] || 0}
          onOpenReport={(w) => {
            setSelectedWallpaper(null);
            setWallpaperForReport(w);
          }}
          onSelectSimilar={(sim) => setSelectedWallpaper(sim)}
          similarWallpapers={similarWallpapers}
          onTriggerToast={addToast}
        />
      )}

      {/* AI Wallpaper Generator Studio Modal */}
      <AIGeneratorModal
        isOpen={isAIStudioOpen}
        onClose={() => setIsAIStudioOpen(false)}
        onWallpaperCreated={handleAddNewWallpaper}
        onTriggerToast={addToast}
      />

      {/* User Auth Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onLogin={(user) => {
          setCurrentUserState(user);
          setCurrentUser(user);
        }}
        onTriggerToast={addToast}
      />

      {/* User Profile Modal */}
      <UserProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        user={currentUser}
        onUpdateUser={(updated) => {
          setCurrentUserState(updated);
          setCurrentUser(updated);
        }}
        userWallpapers={wallpapers.filter((w) => w.isAiGenerated || w.author.handle === '@creator')}
        onOpenWallpaper={(w) => setSelectedWallpaper(w)}
        onTriggerToast={addToast}
      />

      {/* Report Modal */}
      <ReportModal
        wallpaper={wallpaperForReport}
        onClose={() => setWallpaperForReport(null)}
        onSubmitReport={handleSubmitReport}
        onTriggerToast={addToast}
      />

      {/* Legal & Info Modals (About, Contact, Privacy, Terms) */}
      <InfoModals
        type={infoModalType}
        onClose={() => setInfoModalType(null)}
        onTriggerToast={addToast}
      />

      {/* Toast Notification Container */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}
