import { Category, User, Wallpaper, WallpaperReport } from '../types';
import { INITIAL_CATEGORIES, INITIAL_WALLPAPERS } from '../data/wallpapers';

const STORAGE_KEYS = {
  WALLPAPERS: 'lumina_wallpapers_v1',
  CATEGORIES: 'lumina_categories_v1',
  FAVORITES: 'lumina_favorites_v1',
  CURRENT_USER: 'lumina_user_v1',
  REPORTS: 'lumina_reports_v1',
  STATS: 'lumina_stats_v1',
  THEME: 'lumina_theme_v1',
  USER_RATINGS: 'lumina_user_ratings_v1',
};

// Initial default user (demo user)
export const DEFAULT_USER: User = {
  id: 'usr-1',
  name: 'Alex Vance',
  email: 'alex.vance@example.com',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
  role: 'user',
  bio: 'Digital artist & minimalist wallpaper enthusiast. Exploring 4K visual art and AI creation.',
  joinedAt: 'January 2026',
  favoriteIds: ['lum-1', 'lum-2', 'lum-19'],
  downloadsCount: 14,
  generatedCount: 2,
};

// Initial admin user
export const ADMIN_USER: User = {
  id: 'usr-admin',
  name: 'Admin Curator',
  email: 'admin@lumina.art',
  avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
  role: 'admin',
  bio: 'Head of Lumina Wallpapers curation & community moderation.',
  joinedAt: 'October 2025',
  favoriteIds: ['lum-1', 'lum-5', 'lum-17', 'lum-21'],
  downloadsCount: 95,
  generatedCount: 12,
};

// Wallpapers
export function getStoredWallpapers(): Wallpaper[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.WALLPAPERS);
    if (!data) {
      localStorage.setItem(STORAGE_KEYS.WALLPAPERS, JSON.stringify(INITIAL_WALLPAPERS));
      return INITIAL_WALLPAPERS;
    }
    return JSON.parse(data);
  } catch {
    return INITIAL_WALLPAPERS;
  }
}

export function saveWallpapers(wallpapers: Wallpaper[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.WALLPAPERS, JSON.stringify(wallpapers));
  } catch (e) {
    console.error('Failed to save wallpapers to storage:', e);
  }
}

export function addWallpaper(wallpaper: Wallpaper): Wallpaper[] {
  const current = getStoredWallpapers();
  const updated = [wallpaper, ...current];
  saveWallpapers(updated);
  return updated;
}

export function updateWallpaper(updatedWallpaper: Wallpaper): Wallpaper[] {
  const current = getStoredWallpapers();
  const updated = current.map((w) => (w.id === updatedWallpaper.id ? updatedWallpaper : w));
  saveWallpapers(updated);
  return updated;
}

export function deleteWallpaper(id: string): Wallpaper[] {
  const current = getStoredWallpapers();
  const updated = current.filter((w) => w.id !== id);
  saveWallpapers(updated);
  return updated;
}

// Categories
export function getStoredCategories(): Category[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
    if (!data) {
      localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(INITIAL_CATEGORIES));
      return INITIAL_CATEGORIES;
    }
    return JSON.parse(data);
  } catch {
    return INITIAL_CATEGORIES;
  }
}

export function saveCategories(categories: Category[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
  } catch (e) {
    console.error('Failed to save categories to storage:', e);
  }
}

// Favorites
export function getStoredFavoriteIds(): string[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.FAVORITES);
    if (!data) {
      const initial = DEFAULT_USER.favoriteIds;
      localStorage.setItem(STORAGE_KEYS.FAVORITES, JSON.stringify(initial));
      return initial;
    }
    return JSON.parse(data);
  } catch {
    return DEFAULT_USER.favoriteIds;
  }
}

export function toggleFavoriteId(id: string): { favoriteIds: string[]; isFavorite: boolean } {
  const current = getStoredFavoriteIds();
  const isFavorite = current.includes(id);
  const updated = isFavorite ? current.filter((item) => item !== id) : [...current, id];
  try {
    localStorage.setItem(STORAGE_KEYS.FAVORITES, JSON.stringify(updated));
  } catch (e) {
    console.error(e);
  }
  return { favoriteIds: updated, isFavorite: !isFavorite };
}

// User Authentication
export function getCurrentUser(): User | null {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    if (!data) {
      // Default to demo user logged in for immediate seamless testability
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(DEFAULT_USER));
      return DEFAULT_USER;
    }
    return JSON.parse(data);
  } catch {
    return DEFAULT_USER;
  }
}

export function setCurrentUser(user: User | null): void {
  try {
    if (user) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
    } else {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    }
  } catch (e) {
    console.error(e);
  }
}

// User Ratings
export function getUserRatings(): Record<string, number> {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.USER_RATINGS);
    return data ? JSON.parse(data) : {};
  } catch {
    return {};
  }
}

export function setUserRating(wallpaperId: string, rating: number): void {
  try {
    const current = getUserRatings();
    current[wallpaperId] = rating;
    localStorage.setItem(STORAGE_KEYS.USER_RATINGS, JSON.stringify(current));
  } catch (e) {
    console.error(e);
  }
}

// Reports
export function getStoredReports(): WallpaperReport[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.REPORTS);
    if (!data) {
      const initialReports: WallpaperReport[] = [
        {
          id: 'rep-1',
          wallpaperId: 'lum-9',
          wallpaperTitle: 'Futuristic Cyberpunk Mecha Battler',
          reason: 'copyright',
          comment: 'Verify artist attribution guidelines for commercial use.',
          reportedAt: '2026-09-28',
          status: 'pending',
        },
      ];
      localStorage.setItem(STORAGE_KEYS.REPORTS, JSON.stringify(initialReports));
      return initialReports;
    }
    return JSON.parse(data);
  } catch {
    return [];
  }
}

export function addReport(report: Omit<WallpaperReport, 'id' | 'reportedAt' | 'status'>): void {
  const reports = getStoredReports();
  const newReport: WallpaperReport = {
    ...report,
    id: `rep-${Date.now()}`,
    reportedAt: new Date().toISOString().split('T')[0],
    status: 'pending',
  };
  reports.unshift(newReport);
  try {
    localStorage.setItem(STORAGE_KEYS.REPORTS, JSON.stringify(reports));
  } catch (e) {
    console.error(e);
  }
}

export function updateReportStatus(reportId: string, status: 'resolved' | 'dismissed'): WallpaperReport[] {
  const reports = getStoredReports();
  const updated = reports.map((r) => (r.id === reportId ? { ...r, status } : r));
  try {
    localStorage.setItem(STORAGE_KEYS.REPORTS, JSON.stringify(updated));
  } catch (e) {
    console.error(e);
  }
  return updated;
}

// Theme
export function getStoredTheme(): 'dark' | 'light' {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.THEME);
    if (saved === 'light' || saved === 'dark') return saved;
    return 'dark'; // default modern sleek dark mode
  } catch {
    return 'dark';
  }
}

export function setStoredTheme(theme: 'dark' | 'light'): void {
  try {
    localStorage.setItem(STORAGE_KEYS.THEME, theme);
  } catch (e) {
    console.error(e);
  }
}
