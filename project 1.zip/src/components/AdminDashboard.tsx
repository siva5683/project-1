import React, { useState } from 'react';
import {
  ShieldCheck,
  Plus,
  Trash2,
  Edit3,
  BarChart3,
  Image as ImageIcon,
  Layers,
  Flag,
  Users,
  Download,
  Eye,
  CheckCircle2,
  X,
  Search,
  Check,
  Sparkles,
  AlertTriangle,
  Flame,
} from 'lucide-react';
import { Category, User, Wallpaper, WallpaperReport } from '../types';

interface AdminDashboardProps {
  wallpapers: Wallpaper[];
  categories: Category[];
  reports: WallpaperReport[];
  currentUser: User | null;
  onAddWallpaper: (wallpaper: Wallpaper) => void;
  onUpdateWallpaper: (wallpaper: Wallpaper) => void;
  onDeleteWallpaper: (id: string) => void;
  onAddCategory: (category: Category) => void;
  onUpdateCategory: (category: Category) => void;
  onDeleteCategory: (id: string) => void;
  onResolveReport: (reportId: string, status: 'resolved' | 'dismissed') => void;
  onTriggerToast: (type: 'success' | 'error' | 'info', title: string, desc?: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  wallpapers,
  categories,
  reports,
  currentUser,
  onAddWallpaper,
  onUpdateWallpaper,
  onDeleteWallpaper,
  onAddCategory,
  onUpdateCategory,
  onDeleteCategory,
  onResolveReport,
  onTriggerToast,
}) => {
  const [activeTab, setActiveTab] = useState<'stats' | 'wallpapers' | 'categories' | 'reports'>('stats');

  // Search & filter in Admin
  const [wallpaperSearch, setWallpaperSearch] = useState('');
  const [wallpaperCatFilter, setWallpaperCatFilter] = useState('All');

  // Add/Edit Wallpaper Modal State
  const [isWallpaperModalOpen, setIsWallpaperModalOpen] = useState(false);
  const [editingWallpaper, setEditingWallpaper] = useState<Wallpaper | null>(null);

  const [formTitle, setFormTitle] = useState('');
  const [formCategory, setFormCategory] = useState('Nature');
  const [formResolution, setFormResolution] = useState('3840 x 2160 (4K)');
  const [formResCat, setFormResCat] = useState<'4K UHD' | '2K QHD' | '1080p FHD' | 'Ultrawide' | 'Mobile'>('4K UHD');
  const [formAspectRatio, setFormAspectRatio] = useState<'16:9' | '9:16' | '21:9' | '1:1'>('16:9');
  const [formImageUrl, setFormImageUrl] = useState('');
  const [formTags, setFormTags] = useState('');
  const [formAuthorName, setFormAuthorName] = useState('Admin Staff');

  // Add/Edit Category Modal State
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [catName, setCatName] = useState('');
  const [catDesc, setCatDesc] = useState('');
  const [catCover, setCatCover] = useState('');

  // Open modal for new wallpaper
  const openNewWallpaperModal = () => {
    setEditingWallpaper(null);
    setFormTitle('');
    setFormCategory(categories[0]?.name || 'Nature');
    setFormResolution('3840 x 2160 (4K)');
    setFormResCat('4K UHD');
    setFormAspectRatio('16:9');
    setFormImageUrl('');
    setFormTags('4k, wallpaper, modern');
    setFormAuthorName('Admin Staff');
    setIsWallpaperModalOpen(true);
  };

  // Open modal for editing wallpaper
  const openEditWallpaperModal = (w: Wallpaper) => {
    setEditingWallpaper(w);
    setFormTitle(w.title);
    setFormCategory(w.category);
    setFormResolution(w.resolution);
    setFormResCat(w.resolutionCategory as any);
    setFormAspectRatio(w.aspectRatio as any);
    setFormImageUrl(w.imageUrl);
    setFormTags(w.tags ? w.tags.join(', ') : '');
    setFormAuthorName(w.author.name);
    setIsWallpaperModalOpen(true);
  };

  const handleSaveWallpaper = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle || !formImageUrl) {
      onTriggerToast('error', 'Please fill in title and image URL');
      return;
    }

    const tagList = formTags
      .split(',')
      .map((t) => t.trim().toLowerCase())
      .filter(Boolean);

    if (editingWallpaper) {
      const updated: Wallpaper = {
        ...editingWallpaper,
        title: formTitle,
        category: formCategory,
        resolution: formResolution,
        resolutionCategory: formResCat,
        aspectRatio: formAspectRatio,
        imageUrl: formImageUrl,
        thumbnailUrl: formImageUrl,
        tags: tagList,
        author: {
          ...editingWallpaper.author,
          name: formAuthorName,
        },
      };
      onUpdateWallpaper(updated);
      onTriggerToast('success', 'Wallpaper updated successfully!');
    } else {
      const newWp: Wallpaper = {
        id: `lum-admin-${Date.now()}`,
        title: formTitle,
        category: formCategory,
        resolution: formResolution,
        resolutionCategory: formResCat,
        aspectRatio: formAspectRatio,
        fileSize: '7.8 MB',
        imageUrl: formImageUrl,
        thumbnailUrl: formImageUrl,
        downloads: 0,
        likes: 0,
        views: 1,
        rating: 5.0,
        ratingsCount: 1,
        tags: tagList,
        palette: ['#0B0C10', '#1F2833', '#8B5CF6'],
        author: {
          name: formAuthorName,
          handle: '@admin',
          avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=120&q=80',
        },
        createdAt: new Date().toISOString().split('T')[0],
        isLatest: true,
      };
      onAddWallpaper(newWp);
      onTriggerToast('success', 'New wallpaper uploaded to gallery!');
    }
    setIsWallpaperModalOpen(false);
  };

  // Category save
  const handleSaveCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!catName) {
      onTriggerToast('error', 'Category name is required');
      return;
    }

    if (editingCategory) {
      const updated: Category = {
        ...editingCategory,
        name: catName,
        slug: catName.toLowerCase().replace(/\s+/g, '-'),
        description: catDesc || editingCategory.description,
        coverImage: catCover || editingCategory.coverImage,
      };
      onUpdateCategory(updated);
      onTriggerToast('success', `Category "${catName}" updated!`);
    } else {
      const newCat: Category = {
        id: `cat-${Date.now()}`,
        name: catName,
        slug: catName.toLowerCase().replace(/\s+/g, '-'),
        description: catDesc || 'Curated high-resolution wallpapers collection.',
        iconName: 'Folder',
        coverImage: catCover || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
        count: 0,
      };
      onAddCategory(newCat);
      onTriggerToast('success', `Category "${catName}" created!`);
    }
    setIsCategoryModalOpen(false);
  };

  // Filter wallpapers
  const filteredWallpapers = wallpapers.filter((w) => {
    const matchesSearch =
      w.title.toLowerCase().includes(wallpaperSearch.toLowerCase()) ||
      w.category.toLowerCase().includes(wallpaperSearch.toLowerCase());
    const matchesCat =
      wallpaperCatFilter === 'All' || w.category.toLowerCase() === wallpaperCatFilter.toLowerCase();
    return matchesSearch && matchesCat;
  });

  // Calculate statistics
  const totalDownloads = wallpapers.reduce((acc, curr) => acc + curr.downloads, 0);
  const totalLikes = wallpapers.reduce((acc, curr) => acc + curr.likes, 0);
  const totalViews = wallpapers.reduce((acc, curr) => acc + curr.views, 0);
  const pendingReportsCount = reports.filter((r) => r.status === 'pending').length;

  return (
    <div className="py-6 sm:py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-zinc-200 dark:border-zinc-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-emerald-500/10 text-emerald-500 border border-emerald-500/20">
              <ShieldCheck className="w-5 h-5" />
            </span>
            <h1 className="text-2xl sm:text-3xl font-black text-zinc-900 dark:text-white tracking-tight">
              Curator & Admin Portal
            </h1>
          </div>
          <p className="mt-1 text-xs sm:text-sm text-zinc-500 dark:text-zinc-400">
            Manage wallpapers, categories, review reports, and monitor platform performance.
          </p>
        </div>

        {/* Action Button */}
        <div className="flex items-center gap-2">
          <button
            onClick={openNewWallpaperModal}
            className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center gap-2 shadow-md shadow-indigo-600/20 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Upload Wallpaper</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-zinc-200 dark:border-zinc-800 overflow-x-auto pb-1">
        <button
          onClick={() => setActiveTab('stats')}
          className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-t-xl border-b-2 transition-all flex items-center gap-2 ${
            activeTab === 'stats'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 bg-indigo-50/50 dark:bg-indigo-950/30'
              : 'border-transparent text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>Analytics & Statistics</span>
        </button>

        <button
          onClick={() => setActiveTab('wallpapers')}
          className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-t-xl border-b-2 transition-all flex items-center gap-2 ${
            activeTab === 'wallpapers'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 bg-indigo-50/50 dark:bg-indigo-950/30'
              : 'border-transparent text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200'
          }`}
        >
          <ImageIcon className="w-4 h-4" />
          <span>Wallpapers ({wallpapers.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('categories')}
          className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-t-xl border-b-2 transition-all flex items-center gap-2 ${
            activeTab === 'categories'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 bg-indigo-50/50 dark:bg-indigo-950/30'
              : 'border-transparent text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Categories ({categories.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('reports')}
          className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-t-xl border-b-2 transition-all flex items-center gap-2 relative ${
            activeTab === 'reports'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 bg-indigo-50/50 dark:bg-indigo-950/30'
              : 'border-transparent text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200'
          }`}
        >
          <Flag className="w-4 h-4" />
          <span>User Reports</span>
          {pendingReportsCount > 0 && (
            <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-rose-500 text-white">
              {pendingReportsCount}
            </span>
          )}
        </button>
      </div>

      {/* Tab 1: Stats & Analytics */}
      {activeTab === 'stats' && (
        <div className="space-y-6">
          {/* Top Metric Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800">
              <div className="flex items-center justify-between text-zinc-400 mb-1">
                <span className="text-xs font-semibold">Total Downloads</span>
                <Download className="w-4 h-4 text-indigo-500" />
              </div>
              <p className="text-xl sm:text-2xl font-black text-zinc-900 dark:text-white">
                {totalDownloads.toLocaleString()}
              </p>
              <p className="text-[10px] text-emerald-500 font-semibold mt-1">↑ +14.2% this month</p>
            </div>

            <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800">
              <div className="flex items-center justify-between text-zinc-400 mb-1">
                <span className="text-xs font-semibold">Total Wallpapers</span>
                <ImageIcon className="w-4 h-4 text-violet-500" />
              </div>
              <p className="text-xl sm:text-2xl font-black text-zinc-900 dark:text-white">
                {wallpapers.length}
              </p>
              <p className="text-[10px] text-zinc-500 font-semibold mt-1">
                Across {categories.length} categories
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800">
              <div className="flex items-center justify-between text-zinc-400 mb-1">
                <span className="text-xs font-semibold">Total Impressions</span>
                <Eye className="w-4 h-4 text-sky-500" />
              </div>
              <p className="text-xl sm:text-2xl font-black text-zinc-900 dark:text-white">
                {totalViews.toLocaleString()}
              </p>
              <p className="text-[10px] text-emerald-500 font-semibold mt-1">↑ +22.4% engagement</p>
            </div>

            <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800">
              <div className="flex items-center justify-between text-zinc-400 mb-1">
                <span className="text-xs font-semibold">Pending Reports</span>
                <Flag className="w-4 h-4 text-rose-500" />
              </div>
              <p className="text-xl sm:text-2xl font-black text-zinc-900 dark:text-white">
                {pendingReportsCount}
              </p>
              <p className="text-[10px] text-zinc-500 font-semibold mt-1">
                {pendingReportsCount === 0 ? 'All clear' : 'Needs attention'}
              </p>
            </div>
          </div>

          {/* Top Downloaded Wallpapers Leaderboard */}
          <div className="p-5 rounded-2xl bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800">
            <h3 className="text-sm font-bold text-zinc-900 dark:text-white mb-4 flex items-center gap-2">
              <Flame className="w-4 h-4 text-amber-500" />
              <span>Most Downloaded Wallpapers (Top Performers)</span>
            </h3>

            <div className="space-y-3">
              {[...wallpapers]
                .sort((a, b) => b.downloads - a.downloads)
                .slice(0, 5)
                .map((w, index) => {
                  const pct = Math.round((w.downloads / (wallpapers[0]?.downloads || 1)) * 100);
                  return (
                    <div key={w.id} className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          <span className="w-5 font-bold text-zinc-400 font-mono">#{index + 1}</span>
                          <span className="font-semibold text-zinc-800 dark:text-zinc-200 truncate max-w-xs sm:max-w-md">
                            {w.title}
                          </span>
                          <span className="text-[10px] text-zinc-400">({w.category})</span>
                        </div>
                        <span className="font-bold text-indigo-600 dark:text-indigo-400">
                          {w.downloads.toLocaleString()} dl
                        </span>
                      </div>
                      <div className="w-full h-2 rounded-full bg-zinc-200 dark:bg-zinc-800 overflow-hidden">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-violet-500 transition-all duration-500"
                          style={{ width: `${Math.min(pct, 100)}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Wallpapers Management */}
      {activeTab === 'wallpapers' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 flex-1 max-w-sm">
              <div className="relative w-full">
                <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Filter wallpapers by title..."
                  value={wallpaperSearch}
                  onChange={(e) => setWallpaperSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-white"
                />
              </div>
            </div>

            <select
              value={wallpaperCatFilter}
              onChange={(e) => setWallpaperCatFilter(e.target.value)}
              className="text-xs font-semibold px-3 py-1.5 rounded-xl bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-800 dark:text-zinc-200"
            >
              <option value="All">All Categories</option>
              {categories.map((c) => (
                <option key={c.id} value={c.name}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Wallpapers Table */}
          <div className="rounded-2xl border border-zinc-200 dark:border-zinc-800 overflow-hidden bg-white dark:bg-zinc-900">
            <table className="w-full text-left text-xs">
              <thead className="bg-zinc-50 dark:bg-zinc-850/80 border-b border-zinc-200 dark:border-zinc-800 text-zinc-500 dark:text-zinc-400 font-semibold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-3">Wallpaper</th>
                  <th className="p-3">Category</th>
                  <th className="p-3">Resolution</th>
                  <th className="p-3">Downloads</th>
                  <th className="p-3">Rating</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800">
                {filteredWallpapers.map((w) => (
                  <tr key={w.id} className="hover:bg-zinc-50/50 dark:hover:bg-zinc-800/40">
                    <td className="p-3">
                      <div className="flex items-center gap-3">
                        <img
                          src={w.thumbnailUrl || w.imageUrl}
                          alt={w.title}
                          className="w-12 h-8 rounded-lg object-cover ring-1 ring-black/10"
                        />
                        <div className="max-w-[200px] sm:max-w-xs truncate">
                          <p className="font-bold text-zinc-900 dark:text-white truncate">{w.title}</p>
                          <p className="text-[10px] text-zinc-400">{w.author.name}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-3 font-semibold text-zinc-700 dark:text-zinc-300">
                      {w.category}
                    </td>
                    <td className="p-3 font-mono text-[11px] text-zinc-500">{w.resolution}</td>
                    <td className="p-3 font-semibold text-zinc-700 dark:text-zinc-300">
                      {w.downloads.toLocaleString()}
                    </td>
                    <td className="p-3 font-bold text-amber-500">★ {w.rating}</td>
                    <td className="p-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => openEditWallpaperModal(w)}
                          className="p-1.5 rounded-lg text-zinc-600 dark:text-zinc-400 hover:text-indigo-600 hover:bg-zinc-100 dark:hover:bg-zinc-800"
                          title="Edit"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            if (window.confirm(`Delete wallpaper "${w.title}"?`)) {
                              onDeleteWallpaper(w.id);
                              onTriggerToast('info', 'Wallpaper deleted.');
                            }
                          }}
                          className="p-1.5 rounded-lg text-zinc-600 dark:text-zinc-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: Categories Management */}
      {activeTab === 'categories' && (
        <div className="space-y-4">
          <div className="flex justify-end">
            <button
              onClick={() => {
                setEditingCategory(null);
                setCatName('');
                setCatDesc('');
                setCatCover('');
                setIsCategoryModalOpen(true);
              }}
              className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center gap-1.5 shadow-sm"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Category</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {categories.map((c) => (
              <div
                key={c.id}
                className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 flex items-start gap-3"
              >
                <img
                  src={c.coverImage}
                  alt={c.name}
                  className="w-16 h-16 rounded-xl object-cover ring-1 ring-black/10 shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-bold text-zinc-900 dark:text-white truncate">
                      {c.name}
                    </h4>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-200 dark:bg-zinc-800 font-bold text-zinc-600 dark:text-zinc-400">
                      {c.count} items
                    </span>
                  </div>
                  <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1 line-clamp-2">
                    {c.description}
                  </p>

                  <div className="mt-3 flex items-center gap-2">
                    <button
                      onClick={() => {
                        setEditingCategory(c);
                        setCatName(c.name);
                        setCatDesc(c.description);
                        setCatCover(c.coverImage);
                        setIsCategoryModalOpen(true);
                      }}
                      className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
                    >
                      Edit
                    </button>
                    <span className="text-zinc-400">•</span>
                    <button
                      onClick={() => {
                        if (window.confirm(`Delete category "${c.name}"?`)) {
                          onDeleteCategory(c.id);
                          onTriggerToast('info', `Category "${c.name}" deleted.`);
                        }
                      }}
                      className="text-xs font-semibold text-rose-500 hover:underline"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: User Reports */}
      {activeTab === 'reports' && (
        <div className="space-y-4">
          {reports.length > 0 ? (
            <div className="rounded-2xl border border-zinc-200 dark:border-zinc-800 overflow-hidden bg-white dark:bg-zinc-900">
              <table className="w-full text-left text-xs">
                <thead className="bg-zinc-50 dark:bg-zinc-850/80 border-b border-zinc-200 dark:border-zinc-800 text-zinc-500 font-semibold uppercase text-[10px]">
                  <tr>
                    <th className="p-3">Wallpaper</th>
                    <th className="p-3">Report Reason</th>
                    <th className="p-3">Details / Comment</th>
                    <th className="p-3">Date</th>
                    <th className="p-3">Status</th>
                    <th className="p-3 text-right">Triage</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800">
                  {reports.map((r) => (
                    <tr key={r.id}>
                      <td className="p-3 font-bold text-zinc-900 dark:text-white">
                        {r.wallpaperTitle}
                      </td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
                          {r.reason}
                        </span>
                      </td>
                      <td className="p-3 text-zinc-600 dark:text-zinc-300 max-w-xs">{r.comment}</td>
                      <td className="p-3 text-zinc-400 font-mono text-[11px]">{r.reportedAt}</td>
                      <td className="p-3">
                        <span
                          className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                            r.status === 'pending'
                              ? 'bg-rose-500/10 text-rose-500'
                              : 'bg-emerald-500/10 text-emerald-500'
                          }`}
                        >
                          {r.status}
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        {r.status === 'pending' ? (
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => {
                                onResolveReport(r.id, 'resolved');
                                onTriggerToast('success', 'Report marked resolved.');
                              }}
                              className="px-2 py-1 rounded-lg bg-emerald-600 text-white font-semibold text-[10px]"
                            >
                              Resolve
                            </button>
                            <button
                              onClick={() => {
                                onResolveReport(r.id, 'dismissed');
                                onTriggerToast('info', 'Report dismissed.');
                              }}
                              className="px-2 py-1 rounded-lg bg-zinc-200 dark:bg-zinc-700 text-zinc-700 dark:text-zinc-300 font-semibold text-[10px]"
                            >
                              Dismiss
                            </button>
                          </div>
                        ) : (
                          <span className="text-[10px] text-zinc-400 font-semibold">Archived</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-12">
              <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
              <p className="text-sm font-bold text-zinc-800 dark:text-zinc-200">No active reports</p>
              <p className="text-xs text-zinc-500">The platform catalog is fully compliant.</p>
            </div>
          )}
        </div>
      )}

      {/* Modal: Add/Edit Wallpaper */}
      {isWallpaperModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-lg rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-200 dark:border-zinc-800">
              <h3 className="text-base font-bold text-zinc-900 dark:text-white">
                {editingWallpaper ? 'Edit Wallpaper' : 'Upload New 4K Wallpaper'}
              </h3>
              <button
                onClick={() => setIsWallpaperModalOpen(false)}
                className="text-zinc-400 hover:text-zinc-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveWallpaper} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-zinc-700 dark:text-zinc-300 block mb-1">
                  Wallpaper Title
                </label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="e.g. Alpine Sunset in 4K"
                  className="w-full p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-zinc-700 dark:text-zinc-300 block mb-1">
                    Category
                  </label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    className="w-full p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-white font-semibold"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.name}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="font-bold text-zinc-700 dark:text-zinc-300 block mb-1">
                    Resolution Category
                  </label>
                  <select
                    value={formResCat}
                    onChange={(e) => setFormResCat(e.target.value as any)}
                    className="w-full p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-white font-semibold"
                  >
                    <option value="4K UHD">4K UHD</option>
                    <option value="2K QHD">2K QHD</option>
                    <option value="1080p FHD">1080p FHD</option>
                    <option value="Ultrawide">Ultrawide (21:9)</option>
                    <option value="Mobile">Mobile (9:16)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-bold text-zinc-700 dark:text-zinc-300 block mb-1">
                  Image URL (Direct Unsplash / CDN or Data URI)
                </label>
                <input
                  type="url"
                  required
                  value={formImageUrl}
                  onChange={(e) => setFormImageUrl(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-white"
                />
              </div>

              <div>
                <label className="font-bold text-zinc-700 dark:text-zinc-300 block mb-1">
                  Keywords & Tags (comma-separated)
                </label>
                <input
                  type="text"
                  value={formTags}
                  onChange={(e) => setFormTags(e.target.value)}
                  placeholder="nature, sunset, 4k, mountains"
                  className="w-full p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-white"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsWallpaperModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold"
                >
                  {editingWallpaper ? 'Save Changes' : 'Upload Wallpaper'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Add/Edit Category */}
      {isCategoryModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-200 dark:border-zinc-800">
              <h3 className="text-base font-bold text-zinc-900 dark:text-white">
                {editingCategory ? 'Edit Category' : 'Create Category'}
              </h3>
              <button
                onClick={() => setIsCategoryModalOpen(false)}
                className="text-zinc-400 hover:text-zinc-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveCategory} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-zinc-700 dark:text-zinc-300 block mb-1">
                  Category Name
                </label>
                <input
                  type="text"
                  required
                  value={catName}
                  onChange={(e) => setCatName(e.target.value)}
                  placeholder="e.g. Cyberpunk & Sci-Fi"
                  className="w-full p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-white"
                />
              </div>

              <div>
                <label className="font-bold text-zinc-700 dark:text-zinc-300 block mb-1">
                  Description
                </label>
                <textarea
                  rows={2}
                  value={catDesc}
                  onChange={(e) => setCatDesc(e.target.value)}
                  placeholder="Brief summary of what wallpapers are in this category"
                  className="w-full p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-white resize-none"
                />
              </div>

              <div>
                <label className="font-bold text-zinc-700 dark:text-zinc-300 block mb-1">
                  Cover Image URL
                </label>
                <input
                  type="url"
                  value={catCover}
                  onChange={(e) => setCatCover(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-white"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCategoryModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold"
                >
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
