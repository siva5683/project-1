import React, { useState } from 'react';
import {
  Heart,
  Download,
  Trash2,
  Search,
  Sparkles,
  ArrowRight,
  FolderHeart,
} from 'lucide-react';
import { Wallpaper } from '../types';
import { WallpaperCard } from './WallpaperCard';

interface FavoritesViewProps {
  favorites: Wallpaper[];
  onToggleFavorite: (id: string) => void;
  onOpenDetails: (wallpaper: Wallpaper) => void;
  onDownload: (wallpaper: Wallpaper) => void;
  onExplore: () => void;
  onClearFavorites?: () => void;
  onDownloadAllFavorites?: () => void;
}

export const FavoritesView: React.FC<FavoritesViewProps> = ({
  favorites,
  onToggleFavorite,
  onOpenDetails,
  onDownload,
  onExplore,
  onClearFavorites,
  onDownloadAllFavorites,
}) => {
  const [search, setSearch] = useState('');

  const filteredFavorites = favorites.filter(
    (w) =>
      w.title.toLowerCase().includes(search.toLowerCase()) ||
      w.category.toLowerCase().includes(search.toLowerCase()) ||
      w.tags?.some((t) => t.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="py-6 sm:py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-zinc-200 dark:border-zinc-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-rose-500/10 text-rose-500 border border-rose-500/20">
              <Heart className="w-5 h-5 fill-current" />
            </span>
            <h1 className="text-2xl sm:text-3xl font-black text-zinc-900 dark:text-white tracking-tight">
              My Favorite Wallpapers
            </h1>
          </div>
          <p className="mt-1 text-xs sm:text-sm text-zinc-500 dark:text-zinc-400">
            {favorites.length} {favorites.length === 1 ? 'wallpaper' : 'wallpapers'} saved in your personal collection.
          </p>
        </div>

        {favorites.length > 0 && (
          <div className="flex items-center gap-3">
            {onDownloadAllFavorites && (
              <button
                onClick={onDownloadAllFavorites}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center gap-2 shadow-md shadow-indigo-600/20 transition-all"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download All ({favorites.length})</span>
              </button>
            )}

            {onClearFavorites && (
              <button
                onClick={onClearFavorites}
                className="px-3.5 py-2 rounded-xl border border-zinc-200 dark:border-zinc-800 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-rose-600 dark:text-rose-400 text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear All</span>
              </button>
            )}
          </div>
        )}
      </div>

      {favorites.length > 0 ? (
        <div className="space-y-6">
          {/* Search within favorites */}
          <div className="relative max-w-md">
            <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search in your favorites..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 text-xs sm:text-sm rounded-xl bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
            />
          </div>

          {filteredFavorites.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {filteredFavorites.map((wallpaper) => (
                <WallpaperCard
                  key={wallpaper.id}
                  wallpaper={wallpaper}
                  isFavorite={true}
                  onToggleFavorite={onToggleFavorite}
                  onOpenDetails={onOpenDetails}
                  onDownload={onDownload}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-sm font-semibold text-zinc-600 dark:text-zinc-400">
                No favorites matching &quot;{search}&quot;.
              </p>
              <button
                onClick={() => setSearch('')}
                className="mt-2 text-xs text-indigo-600 dark:text-indigo-400 underline font-medium"
              >
                Clear search
              </button>
            </div>
          )}
        </div>
      ) : (
        <div className="text-center py-16 px-4 max-w-md mx-auto space-y-4">
          <div className="w-16 h-16 rounded-3xl bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 flex items-center justify-center mx-auto text-zinc-400">
            <FolderHeart className="w-8 h-8 text-rose-400" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-zinc-900 dark:text-white">
              No favorites saved yet
            </h3>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">
              Click the heart icon on any 4K wallpaper to save it for quick access, customization, and downloading later.
            </p>
          </div>
          <button
            onClick={onExplore}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs inline-flex items-center gap-2 shadow-md transition-all"
          >
            <span>Explore Wallpapers</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
};
