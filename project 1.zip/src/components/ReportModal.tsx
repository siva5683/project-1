import React, { useState } from 'react';
import { X, Flag, AlertTriangle, Check } from 'lucide-react';
import { Wallpaper } from '../types';

interface ReportModalProps {
  wallpaper: Wallpaper | null;
  onClose: () => void;
  onSubmitReport: (
    wallpaperId: string,
    wallpaperTitle: string,
    reason: 'copyright' | 'inappropriate' | 'low_quality' | 'broken' | 'other',
    comment: string
  ) => void;
  onTriggerToast: (type: 'success' | 'error' | 'info', title: string, desc?: string) => void;
}

export const ReportModal: React.FC<ReportModalProps> = ({
  wallpaper,
  onClose,
  onSubmitReport,
  onTriggerToast,
}) => {
  const [reason, setReason] = useState<'copyright' | 'inappropriate' | 'low_quality' | 'broken' | 'other'>(
    'copyright'
  );
  const [comment, setComment] = useState('');

  if (!wallpaper) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmitReport(wallpaper.id, wallpaper.title, reason, comment);
    onTriggerToast(
      'success',
      'Report Submitted',
      'Our curation and moderation team will review this wallpaper shortly.'
    );
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-md rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 p-6 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between pb-3 border-b border-zinc-200 dark:border-zinc-800">
          <div className="flex items-center gap-2 text-rose-500">
            <Flag className="w-4 h-4" />
            <h3 className="text-base font-bold text-zinc-900 dark:text-white">Report Wallpaper</h3>
          </div>
          <button onClick={onClose} className="text-zinc-400 hover:text-zinc-200">
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-zinc-600 dark:text-zinc-400">
          Reporting: <strong className="text-zinc-900 dark:text-white">{wallpaper.title}</strong>
        </p>

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          <div>
            <label className="font-bold text-zinc-700 dark:text-zinc-300 block mb-1.5">
              Reason for Report
            </label>
            <div className="space-y-2">
              {[
                { label: 'Copyright / IP Infringement', value: 'copyright' },
                { label: 'Inappropriate or NSFW Content', value: 'inappropriate' },
                { label: 'Low Quality / Misleading Resolution', value: 'low_quality' },
                { label: 'Broken Link or Image File', value: 'broken' },
                { label: 'Other Issue', value: 'other' },
              ].map((item) => (
                <label
                  key={item.value}
                  className="flex items-center gap-2 p-2.5 rounded-xl border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-50 dark:hover:bg-zinc-800/60 cursor-pointer"
                >
                  <input
                    type="radio"
                    name="reportReason"
                    value={item.value}
                    checked={reason === item.value}
                    onChange={() => setReason(item.value as any)}
                    className="accent-indigo-600"
                  />
                  <span className="font-medium text-zinc-800 dark:text-zinc-200">{item.label}</span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <label className="font-bold text-zinc-700 dark:text-zinc-300 block mb-1">
              Additional Details (optional)
            </label>
            <textarea
              rows={2}
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Describe the issue or link original source..."
              className="w-full p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-white resize-none"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold"
            >
              Submit Report
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
