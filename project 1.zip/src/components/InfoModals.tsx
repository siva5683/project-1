import React, { useState } from 'react';
import { X, Mail, Send, Shield, BookOpen, Info, Check } from 'lucide-react';

interface InfoModalProps {
  type: 'about' | 'contact' | 'privacy' | 'terms' | null;
  onClose: () => void;
  onTriggerToast: (type: 'success' | 'error' | 'info', title: string, desc?: string) => void;
}

export const InfoModals: React.FC<InfoModalProps> = ({ type, onClose, onTriggerToast }) => {
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactMessage, setContactMessage] = useState('');
  const [isSent, setIsSent] = useState(false);

  if (!type) return null;

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSent(true);
    onTriggerToast(
      'success',
      'Message Dispatched!',
      'Thank you for reaching out. We will get back to you shortly.'
    );
    setTimeout(() => {
      onClose();
      setIsSent(false);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-xl rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 p-6 sm:p-8 space-y-4 shadow-2xl relative max-h-[88vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {type === 'about' && (
          <div className="space-y-4 text-xs sm:text-sm text-zinc-600 dark:text-zinc-300">
            <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
              <Info className="w-5 h-5" />
              <h3 className="text-xl font-black text-zinc-900 dark:text-white">About Lumina Wallpapers</h3>
            </div>
            <p className="leading-relaxed">
              Lumina is a premium destination for ultra-high-definition wallpapers (4K UHD, 2K QHD,
              Ultrawide 21:9, and mobile displays). We curate digital art, nature photography,
              automotive design, and anime aesthetics for screens of all sizes.
            </p>
            <p className="leading-relaxed">
              Powered by Google Gemini 3 Pro and Flash generative models, Lumina also allows any creator to generate bespoke studio wallpapers simply by describing their visual vision.
            </p>
            <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200 dark:border-zinc-800 space-y-2">
              <h4 className="font-bold text-zinc-900 dark:text-white">Our Commitments</h4>
              <ul className="list-disc pl-4 space-y-1 text-xs">
                <li>Zero compression degradation on native 4K downloads</li>
                <li>True multi-ratio support (16:9, 9:16, 21:9, 1:1, 4:3, etc.)</li>
                <li>Respect for photographer and creator attribution</li>
                <li>Instant dark and light mode adaptation</li>
              </ul>
            </div>
          </div>
        )}

        {type === 'contact' && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
              <Mail className="w-5 h-5" />
              <h3 className="text-xl font-black text-zinc-900 dark:text-white">Contact Lumina Support</h3>
            </div>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              Have questions, feedback, or artist partnership inquiries? Send our curators a note.
            </p>

            <form onSubmit={handleContactSubmit} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-zinc-700 dark:text-zinc-300 block mb-1">
                  Your Name
                </label>
                <input
                  type="text"
                  required
                  value={contactName}
                  onChange={(e) => setContactName(e.target.value)}
                  placeholder="Taylor Reed"
                  className="w-full p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-white"
                />
              </div>

              <div>
                <label className="font-bold text-zinc-700 dark:text-zinc-300 block mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  value={contactEmail}
                  onChange={(e) => setContactEmail(e.target.value)}
                  placeholder="taylor@example.com"
                  className="w-full p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-white"
                />
              </div>

              <div>
                <label className="font-bold text-zinc-700 dark:text-zinc-300 block mb-1">
                  Your Message
                </label>
                <textarea
                  rows={3}
                  required
                  value={contactMessage}
                  onChange={(e) => setContactMessage(e.target.value)}
                  placeholder="How can we assist you today?"
                  className="w-full p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-white resize-none"
                />
              </div>

              <button
                type="submit"
                disabled={isSent}
                className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md flex items-center justify-center gap-2 transition-all"
              >
                {isSent ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Sent!</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Send Message</span>
                  </>
                )}
              </button>
            </form>
          </div>
        )}

        {type === 'privacy' && (
          <div className="space-y-4 text-xs sm:text-sm text-zinc-600 dark:text-zinc-300">
            <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
              <Shield className="w-5 h-5" />
              <h3 className="text-xl font-black text-zinc-900 dark:text-white">Privacy Policy</h3>
            </div>
            <p className="leading-relaxed">
              We respect your privacy. All preferences, downloaded wallpaper lists, and favorites
              are stored locally in your browser. We do not sell personal data to third parties.
            </p>
            <h4 className="font-bold text-zinc-900 dark:text-white pt-2">Data Usage</h4>
            <p className="leading-relaxed">
              When utilizing the Lumina AI Wallpaper Studio, prompt queries are processed securely
              via official Gemini API endpoints. Images generated belong to you for personal and
              creative desktop/mobile use.
            </p>
          </div>
        )}

        {type === 'terms' && (
          <div className="space-y-4 text-xs sm:text-sm text-zinc-600 dark:text-zinc-300">
            <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
              <BookOpen className="w-5 h-5" />
              <h3 className="text-xl font-black text-zinc-900 dark:text-white">Terms of Service</h3>
            </div>
            <p className="leading-relaxed">
              All wallpapers hosted on Lumina are provided for personal customization of personal
              computers, mobile devices, tablets, and gaming setups. Redistribution for commercial
              sale without author attribution or explicit licensing is prohibited.
            </p>
            <p className="leading-relaxed">
              Users must refrain from uploading copyright-infringing or inappropriate material.
              Reports are audited by community curators.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
