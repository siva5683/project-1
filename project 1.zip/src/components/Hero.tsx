import React from 'react';
import {
  Download,
  Heart,
  Sparkles,
  Search,
  Eye,
  Flame,
  ArrowRight,
  Shield,
  Layers,
  Monitor,
} from 'lucide-react';
import { Wallpaper } from '../types';

interface HeroProps {
  featuredWallpaper: Wallpaper;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onOpenDetails: (wallpaper: Wallpaper) => void;
  onQuickDownload: (wallpaper: Wallpaper) => void;
  onToggleFavorite: (id: string) => void;
  isFavorite: boolean;
  onOpenAIStudio: () => void;
  onSelectCategory: (cat: string) => void;
}

export const Hero: React.FC<HeroProps> = ({
  featuredWallpaper,
  searchQuery,
  onSearchChange,
  onOpenDetails,
  onQuickDownload,
  onToggleFavorite,
  isFavorite,
  onOpenAIStudio,
  onSelectCategory,
}) => {
  const popularPills = [
    { label: 'Cyberpunk', category: 'Cars' },
    { label: 'Space 4K', category: 'Space' },
    { label: 'Anime Rain', category: 'Anime' },
    { label: 'Nature Mist', category: 'Nature' },
    { label: 'Ultrawide 21:9', category: 'All' },
  ];

  return (
    <section className="relative overflow-hidden pt-6 pb-12 sm:pb-16 lg:pb-20">
      {/* Background ambient lighting */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-b from-indigo-500/10 via-violet-500/5 to-transparent blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Column: Heading, Search & AI Generator Callout */}
          <div className="lg:col-span-7 flex flex-col justify-center text-left">
            {/* Pill badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200/80 dark:border-indigo-800/80 w-fit mb-5 shadow-xs">
              <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-xs font-semibold text-indigo-700 dark:text-indigo-300">
                Curated 4K & Ultra HD Wallpapers
              </span>
              <span className="text-zinc-300 dark:text-zinc-700">|</span>
              <span className="text-xs font-bold text-violet-600 dark:text-violet-400 flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                Gemini 3 Pro AI
              </span>
            </div>

            {/* Main Title */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight text-zinc-900 dark:text-white leading-[1.12]">
              Elevate Your Screens With{' '}
              <span className="bg-gradient-to-r from-indigo-600 via-violet-600 to-fuchsia-500 bg-clip-text text-transparent">
                Masterpiece
              </span>{' '}
              Wallpapers.
            </h1>

            {/* Subtitle */}
            <p className="mt-4 text-base sm:text-lg text-zinc-600 dark:text-zinc-300 max-w-xl leading-relaxed">
              Explore thousands of ultra high-definition wallpapers across Nature, Supercars, Anime,
              Space, and Gaming — or generate custom studio-quality wallpapers with Gemini.
            </p>

            {/* Search Input Box */}
            <div className="mt-7 max-w-xl">
              <div className="relative flex items-center shadow-lg shadow-indigo-950/5 dark:shadow-none rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900/90 p-1.5 focus-within:ring-2 focus-within:ring-indigo-500/40 transition-all">
                <Search className="w-5 h-5 text-zinc-400 ml-3 shrink-0" />
                <input
                  type="text"
                  placeholder="Search by keywords, tags, 4K, car model, nature..."
                  value={searchQuery}
                  onChange={(e) => onSearchChange(e.target.value)}
                  className="w-full px-3 py-2.5 bg-transparent text-sm sm:text-base text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none"
                />
                <button
                  onClick={() => onSearchChange(searchQuery || '4K')}
                  className="px-5 py-2.5 rounded-xl font-semibold text-sm bg-indigo-600 hover:bg-indigo-700 text-white transition-colors flex items-center gap-2 shrink-0 shadow-sm"
                >
                  <span>Search</span>
                </button>
              </div>

              {/* Quick tags */}
              <div className="mt-3 flex items-center flex-wrap gap-2 text-xs text-zinc-500 dark:text-zinc-400">
                <span className="font-semibold text-zinc-700 dark:text-zinc-300">Trending:</span>
                {popularPills.map((pill) => (
                  <button
                    key={pill.label}
                    onClick={() => {
                      if (pill.category !== 'All') {
                        onSelectCategory(pill.category);
                      } else {
                        onSearchChange('Ultrawide');
                      }
                    }}
                    className="px-2.5 py-1 rounded-lg bg-zinc-100 dark:bg-zinc-800/80 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 hover:text-indigo-600 dark:hover:text-indigo-300 text-zinc-600 dark:text-zinc-300 transition-colors"
                  >
                    {pill.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Call to Actions & Highlights */}
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <button
                onClick={onOpenAIStudio}
                className="px-6 py-3 rounded-2xl bg-gradient-to-r from-violet-600 via-indigo-600 to-indigo-700 text-white font-semibold text-sm shadow-xl shadow-indigo-600/25 hover:shadow-indigo-600/40 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-2 group"
              >
                <Sparkles className="w-4 h-4 text-amber-300 group-hover:rotate-12 transition-transform" />
                <span>Generate Wallpaper with AI</span>
                <ArrowRight className="w-4 h-4 opacity-70 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={() => onOpenDetails(featuredWallpaper)}
                className="px-5 py-3 rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white/70 dark:bg-zinc-900/70 hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-800 dark:text-zinc-200 font-semibold text-sm transition-colors flex items-center gap-2"
              >
                <Eye className="w-4 h-4 text-zinc-400" />
                <span>Preview Daily Feature</span>
              </button>
            </div>

            {/* Quick Metrics */}
            <div className="mt-10 pt-6 border-t border-zinc-200 dark:border-zinc-800/80 grid grid-cols-3 gap-4 max-w-lg">
              <div>
                <p className="text-xl sm:text-2xl font-black text-zinc-900 dark:text-white">
                  3,840<span className="text-indigo-500 font-semibold text-sm">px</span>
                </p>
                <p className="text-xs text-zinc-500 dark:text-zinc-400 font-medium">True 4K UHD Quality</p>
              </div>
              <div>
                <p className="text-xl sm:text-2xl font-black text-zinc-900 dark:text-white">
                  10+
                </p>
                <p className="text-xs text-zinc-500 dark:text-zinc-400 font-medium">Curated Categories</p>
              </div>
              <div>
                <p className="text-xl sm:text-2xl font-black text-violet-600 dark:text-violet-400">
                  Gemini 3
                </p>
                <p className="text-xs text-zinc-500 dark:text-zinc-400 font-medium">AI Custom Studio</p>
              </div>
            </div>
          </div>

          {/* Right Column: Featured Wallpaper Spotlight Showcase */}
          <div className="lg:col-span-5 relative">
            <div className="relative group rounded-3xl overflow-hidden shadow-2xl shadow-indigo-950/20 border border-zinc-200 dark:border-zinc-800 bg-zinc-900 aspect-[16/10] sm:aspect-[16/11]">
              {/* Featured Wallpaper Image */}
              <img
                src={featuredWallpaper.imageUrl}
                alt={featuredWallpaper.title}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                loading="eager"
              />

              {/* Gradient overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/40 to-transparent" />

              {/* Top Badges */}
              <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-400 text-zinc-950 flex items-center gap-1 shadow-md">
                    <Flame className="w-3.5 h-3.5 fill-current" />
                    DAILY SPOTLIGHT
                  </span>
                  <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-black/60 backdrop-blur-md text-white border border-white/10">
                    {featuredWallpaper.resolution}
                  </span>
                </div>

                {/* Favorite button */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleFavorite(featuredWallpaper.id);
                  }}
                  className={`p-2.5 rounded-full backdrop-blur-md transition-all ${
                    isFavorite
                      ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/30'
                      : 'bg-black/50 text-white hover:bg-black/80 hover:scale-110'
                  }`}
                  aria-label="Save to favorites"
                >
                  <Heart className={`w-4 h-4 ${isFavorite ? 'fill-current' : ''}`} />
                </button>
              </div>

              {/* Bottom Info & Quick Actions */}
              <div className="absolute bottom-4 left-4 right-4 text-white">
                <div className="flex items-center gap-2 text-xs text-zinc-300 font-medium mb-1">
                  <span className="px-2 py-0.5 rounded bg-indigo-500/30 border border-indigo-400/30 text-indigo-300 font-semibold">
                    {featuredWallpaper.category}
                  </span>
                  <span>•</span>
                  <span>{featuredWallpaper.downloads.toLocaleString()} downloads</span>
                  <span>•</span>
                  <span className="text-amber-400">★ {featuredWallpaper.rating}</span>
                </div>

                <h3 className="text-lg sm:text-xl font-bold tracking-tight text-white drop-shadow-sm line-clamp-1">
                  {featuredWallpaper.title}
                </h3>

                <div className="mt-3 flex items-center justify-between gap-3 pt-3 border-t border-white/15">
                  <div className="flex items-center gap-2">
                    <img
                      src={featuredWallpaper.author.avatar}
                      alt={featuredWallpaper.author.name}
                      className="w-6 h-6 rounded-full object-cover ring-1 ring-white/30"
                    />
                    <span className="text-xs text-zinc-300 font-medium">
                      {featuredWallpaper.author.name}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onOpenDetails(featuredWallpaper)}
                      className="px-3 py-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white text-xs font-semibold backdrop-blur-md transition-colors"
                    >
                      Inspect
                    </button>
                    <button
                      onClick={() => onQuickDownload(featuredWallpaper)}
                      className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-md shadow-indigo-600/30 flex items-center gap-1.5 transition-colors"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
