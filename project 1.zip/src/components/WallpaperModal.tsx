import React, { useState } from 'react';
import {
  X,
  Download,
  Heart,
  Share2,
  Flag,
  Star,
  Eye,
  Check,
  Copy,
  Monitor,
  Smartphone,
  Tablet,
  Sparkles,
  Maximize2,
  Calendar,
  Layers,
  Tag,
  Palette,
  HardDrive,
  Info,
  ChevronRight,
  ExternalLink,
} from 'lucide-react';
import { Wallpaper } from '../types';

interface WallpaperModalProps {
  wallpaper: Wallpaper | null;
  onClose: () => void;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
  onDownload: (wallpaper: Wallpaper, resolutionLabel?: string) => void;
  onRateWallpaper: (wallpaperId: string, rating: number) => void;
  userRating: number;
  onOpenReport: (wallpaper: Wallpaper) => void;
  onSelectSimilar: (wallpaper: Wallpaper) => void;
  similarWallpapers: Wallpaper[];
  onTriggerToast: (type: 'success' | 'error' | 'info', title: string, desc?: string) => void;
}

export const WallpaperModal: React.FC<WallpaperModalProps> = ({
  wallpaper,
  onClose,
  isFavorite,
  onToggleFavorite,
  onDownload,
  onRateWallpaper,
  userRating,
  onOpenReport,
  onSelectSimilar,
  similarWallpapers,
  onTriggerToast,
}) => {
  const [devicePreview, setDevicePreview] = useState<'desktop' | 'mobile' | 'tablet' | 'raw'>('raw');
  const [showShareMenu, setShowShareMenu] = useState(false);
  const [hoverRating, setHoverRating] = useState(0);
  const [copiedColor, setCopiedColor] = useState<string | null>(null);

  if (!wallpaper) return null;

  const downloadResolutions = [
    { label: '4K Ultra HD', resolution: '3840 x 2160', size: wallpaper.fileSize },
    { label: '2K QHD', resolution: '2560 x 1440', size: '4.8 MB' },
    { label: '1080p Full HD', resolution: '1920 x 1080', size: '2.6 MB' },
    { label: 'Smartphone Portrait', resolution: '1440 x 3200', size: '3.4 MB' },
  ];

  const handleShare = async (platform?: string) => {
    const shareUrl = window.location.href;
    const shareText = `Check out this 4K wallpaper: "${wallpaper.title}" on Lumina Wallpapers!`;

    if (!platform && navigator.share) {
      try {
        await navigator.share({
          title: wallpaper.title,
          text: shareText,
          url: shareUrl,
        });
        onTriggerToast('success', 'Shared successfully!');
        return;
      } catch {
        // user cancelled or failed, fallback to copy
      }
    }

    if (platform === 'twitter') {
      window.open(
        `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`,
        '_blank'
      );
    } else if (platform === 'pinterest') {
      window.open(
        `https://pinterest.com/pin/create/button/?url=${encodeURIComponent(shareUrl)}&media=${encodeURIComponent(wallpaper.imageUrl)}&description=${encodeURIComponent(shareText)}`,
        '_blank'
      );
    } else if (platform === 'whatsapp') {
      window.open(
        `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText + ' ' + shareUrl)}`,
        '_blank'
      );
    } else {
      // Copy Link
      navigator.clipboard.writeText(shareUrl);
      onTriggerToast('success', 'Link copied to clipboard!', 'You can now share this wallpaper.');
    }
    setShowShareMenu(false);
  };

  const copyHexColor = (hex: string) => {
    navigator.clipboard.writeText(hex);
    setCopiedColor(hex);
    onTriggerToast('info', `Copied ${hex} to clipboard!`);
    setTimeout(() => setCopiedColor(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 md:p-8 bg-zinc-950/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-6xl my-auto rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Top Header Bar */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900/90 shrink-0">
          <div className="flex items-center gap-2.5 overflow-hidden">
            <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 shrink-0">
              {wallpaper.category}
            </span>
            <h2 className="text-base sm:text-lg font-bold text-zinc-900 dark:text-white truncate">
              {wallpaper.title}
            </h2>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* Device preview switcher */}
            <div className="hidden sm:flex items-center rounded-xl bg-zinc-200/80 dark:bg-zinc-800 p-0.5 text-xs font-semibold">
              <button
                onClick={() => setDevicePreview('raw')}
                className={`px-2.5 py-1 rounded-lg transition-colors ${
                  devicePreview === 'raw'
                    ? 'bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white shadow-xs'
                    : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
                }`}
              >
                Full Image
              </button>
              <button
                onClick={() => setDevicePreview('desktop')}
                className={`p-1.5 rounded-lg transition-colors ${
                  devicePreview === 'desktop'
                    ? 'bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white shadow-xs'
                    : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
                }`}
                title="Desktop Mockup"
              >
                <Monitor className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setDevicePreview('mobile')}
                className={`p-1.5 rounded-lg transition-colors ${
                  devicePreview === 'mobile'
                    ? 'bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white shadow-xs'
                    : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
                }`}
                title="Smartphone Mockup"
              >
                <Smartphone className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setDevicePreview('tablet')}
                className={`p-1.5 rounded-lg transition-colors ${
                  devicePreview === 'tablet'
                    ? 'bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white shadow-xs'
                    : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
                }`}
                title="Tablet Mockup"
              >
                <Tablet className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Favorite button */}
            <button
              onClick={() => onToggleFavorite(wallpaper.id)}
              className={`p-2 rounded-xl border transition-all ${
                isFavorite
                  ? 'bg-rose-500 text-white border-rose-500 shadow-md shadow-rose-500/20'
                  : 'bg-white dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 hover:text-rose-500'
              }`}
              title={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
            >
              <Heart className={`w-4 h-4 ${isFavorite ? 'fill-current' : ''}`} />
            </button>

            {/* Share Menu Trigger */}
            <div className="relative">
              <button
                onClick={() => setShowShareMenu(!showShareMenu)}
                className="p-2 rounded-xl bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-700 transition-colors"
                title="Share wallpaper"
              >
                <Share2 className="w-4 h-4" />
              </button>

              {showShareMenu && (
                <div
                  onMouseLeave={() => setShowShareMenu(false)}
                  className="absolute right-0 mt-2 w-48 p-2 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-2xl z-50 animate-in fade-in"
                >
                  <p className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-zinc-400">
                    Share Wallpaper
                  </p>
                  <button
                    onClick={() => handleShare()}
                    className="w-full px-2.5 py-1.5 text-left text-xs rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300 flex items-center gap-2"
                  >
                    <Copy className="w-3.5 h-3.5 text-zinc-500" />
                    <span>Copy Link</span>
                  </button>
                  <button
                    onClick={() => handleShare('twitter')}
                    className="w-full px-2.5 py-1.5 text-left text-xs rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300 flex items-center gap-2"
                  >
                    <span className="font-bold text-xs">𝕏</span>
                    <span>Twitter / X</span>
                  </button>
                  <button
                    onClick={() => handleShare('pinterest')}
                    className="w-full px-2.5 py-1.5 text-left text-xs rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300 flex items-center gap-2"
                  >
                    <span className="text-rose-500 font-bold text-xs">P</span>
                    <span>Pinterest</span>
                  </button>
                  <button
                    onClick={() => handleShare('whatsapp')}
                    className="w-full px-2.5 py-1.5 text-left text-xs rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300 flex items-center gap-2"
                  >
                    <span className="text-emerald-500 font-bold text-xs">W</span>
                    <span>WhatsApp</span>
                  </button>
                </div>
              )}
            </div>

            {/* Close Button */}
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-500 hover:text-zinc-900 dark:hover:text-white transition-colors"
              aria-label="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Scrollable Content Body */}
        <div className="overflow-y-auto flex-1 p-4 sm:p-6 lg:p-8 space-y-8">
          {/* Main Visual Display (Raw or Mockup) */}
          <div className="flex items-center justify-center bg-zinc-950 rounded-2xl p-2 sm:p-6 min-h-[340px] sm:min-h-[460px] relative overflow-hidden group">
            {devicePreview === 'raw' && (
              <div className="relative max-h-[65vh] w-full flex items-center justify-center">
                <img
                  src={wallpaper.imageUrl}
                  alt={wallpaper.title}
                  className="max-h-[65vh] max-w-full rounded-xl object-contain shadow-2xl"
                />
                <a
                  href={wallpaper.imageUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="absolute bottom-4 right-4 p-2 rounded-xl bg-black/60 hover:bg-black/90 backdrop-blur-md text-white text-xs font-semibold flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Maximize2 className="w-3.5 h-3.5" />
                  <span>Open Raw 4K</span>
                </a>
              </div>
            )}

            {/* Desktop Mockup Preview */}
            {devicePreview === 'desktop' && (
              <div className="w-full max-w-2xl bg-zinc-900 border-4 border-zinc-700 rounded-2xl shadow-2xl p-2 flex flex-col items-center animate-in zoom-in-95">
                <div className="w-full flex items-center justify-between pb-1.5 px-2">
                  <div className="flex gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                    <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                    <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  </div>
                  <span className="text-[10px] text-zinc-500 font-mono">macOS Studio Display</span>
                  <div className="w-6" />
                </div>
                <div className="w-full aspect-[16/9] rounded-lg overflow-hidden relative">
                  <img
                    src={wallpaper.imageUrl}
                    alt={wallpaper.title}
                    className="w-full h-full object-cover"
                  />
                  {/* Subtle dock at the bottom */}
                  <div className="absolute bottom-2 left-1/2 -translate-x-1/2 px-4 py-1.5 rounded-2xl bg-white/20 backdrop-blur-lg flex gap-2">
                    <div className="w-4 h-4 rounded bg-indigo-500" />
                    <div className="w-4 h-4 rounded bg-emerald-500" />
                    <div className="w-4 h-4 rounded bg-amber-500" />
                    <div className="w-4 h-4 rounded bg-rose-500" />
                  </div>
                </div>
                <div className="w-20 h-4 bg-zinc-700 mt-2 rounded-b" />
                <div className="w-32 h-1.5 bg-zinc-600 rounded-full" />
              </div>
            )}

            {/* Smartphone Mockup Preview */}
            {devicePreview === 'mobile' && (
              <div className="w-64 aspect-[9/19] bg-zinc-900 border-4 border-zinc-700 rounded-[2.5rem] shadow-2xl p-2.5 flex flex-col relative overflow-hidden animate-in zoom-in-95">
                {/* Dynamic island */}
                <div className="absolute top-4 left-1/2 -translate-x-1/2 w-20 h-4 bg-black rounded-full z-10" />
                <div className="w-full h-full rounded-[2rem] overflow-hidden relative">
                  <img
                    src={wallpaper.imageUrl}
                    alt={wallpaper.title}
                    className="w-full h-full object-cover"
                  />
                  {/* Clock overlay */}
                  <div className="absolute top-12 left-0 right-0 text-center text-white">
                    <p className="text-3xl font-extralight tracking-tight drop-shadow-md">09:41</p>
                    <p className="text-xs text-white/80 font-medium drop-shadow-sm">
                      Thursday, October 2
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Tablet Mockup Preview */}
            {devicePreview === 'tablet' && (
              <div className="w-full max-w-lg aspect-[4/3] bg-zinc-900 border-4 border-zinc-700 rounded-3xl shadow-2xl p-3 flex flex-col relative overflow-hidden animate-in zoom-in-95">
                <div className="w-full h-full rounded-2xl overflow-hidden relative">
                  <img
                    src={wallpaper.imageUrl}
                    alt={wallpaper.title}
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Details & Download Action Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Left: Metadata, Colors, Rating, Author */}
            <div className="lg:col-span-7 space-y-6">
              {/* Author & Basic Stats */}
              <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200 dark:border-zinc-800">
                <div className="flex items-center gap-3">
                  <img
                    src={wallpaper.author.avatar}
                    alt={wallpaper.author.name}
                    className="w-11 h-11 rounded-full object-cover ring-2 ring-indigo-500/20"
                  />
                  <div>
                    <h4 className="text-sm font-bold text-zinc-900 dark:text-white">
                      {wallpaper.author.name}
                    </h4>
                    <p className="text-xs text-zinc-500 dark:text-zinc-400">
                      {wallpaper.author.handle}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-xs font-semibold text-zinc-600 dark:text-zinc-300">
                  <div className="flex items-center gap-1.5">
                    <Download className="w-4 h-4 text-indigo-500" />
                    <span>{wallpaper.downloads.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Eye className="w-4 h-4 text-sky-500" />
                    <span>{wallpaper.views.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-amber-500">
                    <Star className="w-4 h-4 fill-current" />
                    <span>{wallpaper.rating} ({wallpaper.ratingsCount})</span>
                  </div>
                </div>
              </div>

              {/* AI Generation Prompt info if present */}
              {wallpaper.isAiGenerated && wallpaper.aiPrompt && (
                <div className="p-4 rounded-2xl bg-gradient-to-r from-violet-500/10 via-indigo-500/10 to-transparent border border-violet-500/20">
                  <div className="flex items-center gap-2 text-xs font-bold text-violet-600 dark:text-violet-400 uppercase tracking-wider mb-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>AI Studio Generated ({wallpaper.aiModel || 'Gemini 3 Pro'})</span>
                  </div>
                  <p className="text-xs text-zinc-700 dark:text-zinc-300 italic leading-relaxed">
                    &quot;{wallpaper.aiPrompt}&quot;
                  </p>
                </div>
              )}

              {/* Specs Grid */}
              <div>
                <h5 className="text-xs font-bold uppercase tracking-wider text-zinc-400 dark:text-zinc-500 mb-3">
                  Technical Specifications
                </h5>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200 dark:border-zinc-800">
                    <p className="text-[10px] text-zinc-500 font-semibold">Native Resolution</p>
                    <p className="text-xs font-bold text-zinc-900 dark:text-white mt-0.5">
                      {wallpaper.resolution}
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200 dark:border-zinc-800">
                    <p className="text-[10px] text-zinc-500 font-semibold">Aspect Ratio</p>
                    <p className="text-xs font-bold text-zinc-900 dark:text-white mt-0.5">
                      {wallpaper.aspectRatio}
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200 dark:border-zinc-800">
                    <p className="text-[10px] text-zinc-500 font-semibold">File Size</p>
                    <p className="text-xs font-bold text-zinc-900 dark:text-white mt-0.5">
                      {wallpaper.fileSize}
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200 dark:border-zinc-800">
                    <p className="text-[10px] text-zinc-500 font-semibold">Published</p>
                    <p className="text-xs font-bold text-zinc-900 dark:text-white mt-0.5">
                      {wallpaper.createdAt}
                    </p>
                  </div>
                </div>
              </div>

              {/* Color Palette Swatches */}
              {wallpaper.palette && wallpaper.palette.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h5 className="text-xs font-bold uppercase tracking-wider text-zinc-400 dark:text-zinc-500 flex items-center gap-1.5">
                      <Palette className="w-3.5 h-3.5" />
                      Color Palette (Click to Copy HEX)
                    </h5>
                    {copiedColor && (
                      <span className="text-xs text-emerald-500 font-semibold">
                        Copied {copiedColor}!
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    {wallpaper.palette.map((color) => (
                      <button
                        key={color}
                        onClick={() => copyHexColor(color)}
                        className="group relative flex-1 h-8 rounded-lg border border-black/10 dark:border-white/10 transition-transform hover:scale-105 active:scale-95 shadow-xs"
                        style={{ backgroundColor: color }}
                        title={`Copy ${color}`}
                      >
                        <span className="opacity-0 group-hover:opacity-100 absolute -top-7 left-1/2 -translate-x-1/2 px-1.5 py-0.5 rounded text-[10px] bg-black text-white font-mono pointer-events-none transition-opacity">
                          {color}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Tags */}
              {wallpaper.tags && (
                <div>
                  <h5 className="text-xs font-bold uppercase tracking-wider text-zinc-400 dark:text-zinc-500 mb-2 flex items-center gap-1.5">
                    <Tag className="w-3.5 h-3.5" />
                    Keywords & Tags
                  </h5>
                  <div className="flex flex-wrap gap-1.5">
                    {wallpaper.tags.map((tag) => (
                      <span
                        key={tag}
                        className="px-2.5 py-1 rounded-lg text-xs font-medium bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-700"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Interactive Rating System */}
              <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
                <div>
                  <p className="text-xs font-bold text-zinc-900 dark:text-white">
                    Rate This Wallpaper
                  </p>
                  <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                    {userRating > 0
                      ? `You rated this ${userRating} stars!`
                      : 'Help curators and community rank quality'}
                  </p>
                </div>

                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      onMouseEnter={() => setHoverRating(star)}
                      onMouseLeave={() => setHoverRating(0)}
                      onClick={() => {
                        onRateWallpaper(wallpaper.id, star);
                        onTriggerToast(
                          'success',
                          `Rated ${star} Stars!`,
                          'Thank you for your feedback.'
                        );
                      }}
                      className="p-1 text-zinc-300 dark:text-zinc-600 hover:scale-125 transition-transform"
                    >
                      <Star
                        className={`w-5 h-5 ${
                          (hoverRating || userRating) >= star
                            ? 'text-amber-400 fill-amber-400'
                            : ''
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>

              {/* Report button */}
              <div className="flex justify-end">
                <button
                  onClick={() => onOpenReport(wallpaper)}
                  className="text-xs text-zinc-400 hover:text-rose-500 font-medium flex items-center gap-1.5 transition-colors"
                >
                  <Flag className="w-3.5 h-3.5" />
                  <span>Report wallpaper</span>
                </button>
              </div>
            </div>

            {/* Right: High Quality Download Multi-Resolution Selector */}
            <div className="lg:col-span-5 space-y-4">
              <div className="p-5 rounded-2xl bg-gradient-to-b from-indigo-500/10 via-zinc-50 to-zinc-50 dark:from-indigo-950/40 dark:via-zinc-900 dark:to-zinc-900 border border-indigo-500/20 dark:border-indigo-500/30 shadow-lg">
                <h4 className="text-base font-bold text-zinc-900 dark:text-white flex items-center gap-2">
                  <Download className="w-5 h-5 text-indigo-500" />
                  <span>Download High-Resolution</span>
                </h4>
                <p className="text-xs text-zinc-600 dark:text-zinc-400 mt-1">
                  Available in multiple cropped and uncompressed resolutions. Free for personal
                  desktop & mobile use.
                </p>

                {/* Primary Quick Download Button */}
                <button
                  onClick={() => onDownload(wallpaper, '4K Ultra HD')}
                  className="w-full mt-4 py-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-xl shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Original 4K UHD</span>
                  <span className="text-xs opacity-75 font-normal">({wallpaper.fileSize})</span>
                </button>

                {/* Alternative Resolution Buttons */}
                <div className="mt-4 pt-4 border-t border-zinc-200 dark:border-zinc-800 space-y-2">
                  <p className="text-[11px] font-bold uppercase tracking-wider text-zinc-400 mb-2">
                    Other Formats & Dimensions
                  </p>
                  {downloadResolutions.map((res) => (
                    <button
                      key={res.label}
                      onClick={() => onDownload(wallpaper, res.label)}
                      className="w-full px-3 py-2.5 rounded-xl bg-white dark:bg-zinc-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 border border-zinc-200 dark:border-zinc-700 hover:border-indigo-400/50 flex items-center justify-between text-xs transition-colors group"
                    >
                      <div className="text-left">
                        <p className="font-semibold text-zinc-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400">
                          {res.label}
                        </p>
                        <p className="text-[10px] text-zinc-500 font-mono">{res.resolution}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-zinc-400 font-medium">{res.size}</span>
                        <Download className="w-3.5 h-3.5 text-zinc-400 group-hover:text-indigo-500 transition-colors" />
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Similar Wallpapers Section */}
          {similarWallpapers.length > 0 && (
            <div className="pt-6 border-t border-zinc-200 dark:border-zinc-800">
              <h4 className="text-base font-bold text-zinc-900 dark:text-white mb-4 flex items-center gap-2">
                <span>More Like This in {wallpaper.category}</span>
                <ChevronRight className="w-4 h-4 text-zinc-400" />
              </h4>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {similarWallpapers.slice(0, 4).map((sim) => (
                  <div
                    key={sim.id}
                    onClick={() => onSelectSimilar(sim)}
                    className="group rounded-xl overflow-hidden aspect-[16/10] relative cursor-pointer border border-zinc-200 dark:border-zinc-800 shadow-sm hover:shadow-lg transition-all"
                  >
                    <img
                      src={sim.thumbnailUrl || sim.imageUrl}
                      alt={sim.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-80 group-hover:opacity-100 transition-opacity" />
                    <div className="absolute bottom-2 left-2 right-2 text-white">
                      <p className="text-xs font-bold truncate">{sim.title}</p>
                      <p className="text-[10px] text-zinc-300">{sim.resolutionCategory}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
