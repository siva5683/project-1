import React, { useState } from 'react';
import {
  X,
  User as UserIcon,
  Heart,
  Download,
  Sparkles,
  Calendar,
  Mail,
  Edit2,
  Check,
  Shield,
  Layers,
} from 'lucide-react';
import { User, Wallpaper } from '../types';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User | null;
  onUpdateUser: (updatedUser: User) => void;
  userWallpapers: Wallpaper[];
  onOpenWallpaper: (wallpaper: Wallpaper) => void;
  onTriggerToast: (type: 'success' | 'error' | 'info', title: string, desc?: string) => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  isOpen,
  onClose,
  user,
  onUpdateUser,
  userWallpapers,
  onOpenWallpaper,
  onTriggerToast,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(user?.name || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [activeProfileTab, setActiveProfileTab] = useState<'creations' | 'about'>('creations');

  if (!isOpen || !user) return null;

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: User = {
      ...user,
      name,
      bio,
    };
    onUpdateUser(updated);
    setIsEditing(false);
    onTriggerToast('success', 'Profile updated successfully!');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-2xl rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Banner with avatar */}
        <div className="relative h-28 bg-gradient-to-r from-indigo-600 via-violet-600 to-fuchsia-600 p-4">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full bg-black/40 text-white hover:bg-black/70 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="px-6 pb-6 pt-0 relative flex-1 overflow-y-auto">
          {/* Avatar & Badges */}
          <div className="flex flex-wrap items-end justify-between gap-4 -mt-12 mb-4">
            <div className="flex items-end gap-3.5">
              <img
                src={user.avatar}
                alt={user.name}
                className="w-24 h-24 rounded-2xl object-cover ring-4 ring-white dark:ring-zinc-900 shadow-xl"
              />
              <div className="mb-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-xl font-black text-zinc-900 dark:text-white tracking-tight">
                    {user.name}
                  </h3>
                  <span className="text-[10px] uppercase font-extrabold px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20">
                    {user.role}
                  </span>
                </div>
                <p className="text-xs text-zinc-500 dark:text-zinc-400">{user.email}</p>
              </div>
            </div>

            <button
              onClick={() => setIsEditing(!isEditing)}
              className="px-3.5 py-1.5 rounded-xl border border-zinc-200 dark:border-zinc-700 text-xs font-semibold text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors flex items-center gap-1.5"
            >
              <Edit2 className="w-3.5 h-3.5" />
              <span>{isEditing ? 'Cancel' : 'Edit Profile'}</span>
            </button>
          </div>

          {/* Edit form */}
          {isEditing ? (
            <form
              onSubmit={handleSaveProfile}
              className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200 dark:border-zinc-700 space-y-3 mb-6 text-xs"
            >
              <div>
                <label className="font-bold text-zinc-700 dark:text-zinc-300 block mb-1">
                  Display Name
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-white"
                />
              </div>

              <div>
                <label className="font-bold text-zinc-700 dark:text-zinc-300 block mb-1">
                  Bio / About You
                </label>
                <textarea
                  rows={2}
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-white resize-none"
                />
              </div>

              <div className="flex justify-end gap-2">
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-indigo-600 text-white font-bold"
                >
                  Save Profile
                </button>
              </div>
            </form>
          ) : (
            <p className="text-xs sm:text-sm text-zinc-600 dark:text-zinc-300 leading-relaxed mb-6">
              {user.bio || 'Curator and collector of high-definition digital wallpapers.'}
            </p>
          )}

          {/* Stats Grid */}
          <div className="grid grid-cols-3 gap-3 mb-6">
            <div className="p-3.5 rounded-2xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200 dark:border-zinc-800 text-center">
              <p className="text-xs text-zinc-500 font-semibold flex items-center justify-center gap-1">
                <Heart className="w-3.5 h-3.5 text-rose-500" />
                <span>Favorites</span>
              </p>
              <p className="text-xl font-black text-zinc-900 dark:text-white mt-1">
                {user.favoriteIds.length}
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200 dark:border-zinc-800 text-center">
              <p className="text-xs text-zinc-500 font-semibold flex items-center justify-center gap-1">
                <Download className="w-3.5 h-3.5 text-indigo-500" />
                <span>Downloads</span>
              </p>
              <p className="text-xl font-black text-zinc-900 dark:text-white mt-1">
                {user.downloadsCount}
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200 dark:border-zinc-800 text-center">
              <p className="text-xs text-zinc-500 font-semibold flex items-center justify-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-violet-500" />
                <span>AI Generations</span>
              </p>
              <p className="text-xl font-black text-zinc-900 dark:text-white mt-1">
                {userWallpapers.length}
              </p>
            </div>
          </div>

          {/* User's Created/Generated Wallpapers */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 mb-3 flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 text-violet-500" />
              <span>My AI Generated & Uploaded Wallpapers ({userWallpapers.length})</span>
            </h4>

            {userWallpapers.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {userWallpapers.map((w) => (
                  <div
                    key={w.id}
                    onClick={() => {
                      onOpenWallpaper(w);
                      onClose();
                    }}
                    className="group rounded-xl overflow-hidden aspect-[16/10] relative cursor-pointer border border-zinc-200 dark:border-zinc-800 shadow-sm"
                  >
                    <img
                      src={w.thumbnailUrl || w.imageUrl}
                      alt={w.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent" />
                    <p className="absolute bottom-2 left-2 right-2 text-[11px] font-bold text-white truncate">
                      {w.title}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 rounded-2xl border border-dashed border-zinc-200 dark:border-zinc-800">
                <p className="text-xs text-zinc-500">
                  No wallpapers generated yet. Launch the AI Studio to create bespoke 4K art!
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
