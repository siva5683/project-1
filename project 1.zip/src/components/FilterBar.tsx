import React, { useState } from 'react';
import {
  SlidersHorizontal,
  Monitor,
  Smartphone,
  Sparkles,
  ArrowUpDown,
  Palette,
  X,
  Check,
  LayoutGrid,
  Grid,
} from 'lucide-react';
import { FilterState, ResolutionCategory } from '../types';

interface FilterBarProps {
  filters: FilterState;
  onFilterChange: (newFilters: FilterState) => void;
  totalResults: number;
  layoutMode: 'standard' | 'compact';
  onToggleLayout: (mode: 'standard' | 'compact') => void;
}

const RESOLUTIONS: { label: string; value: ResolutionCategory }[] = [
  { label: 'All Resolutions', value: 'All' },
  { label: '4K UHD (3840p)', value: '4K UHD' },
  { label: '2K QHD (1440p)', value: '2K QHD' },
  { label: '1080p FHD', value: '1080p FHD' },
  { label: '21:9 Ultrawide', value: 'Ultrawide' },
  { label: 'Mobile (Phone)', value: 'Mobile' },
];

const ASPECT_RATIOS = [
  { label: 'All Ratios', value: 'All' },
  { label: '16:9 Desktop', value: '16:9' },
  { label: '9:16 Phone', value: '9:16' },
  { label: '21:9 Ultrawide', value: '21:9' },
  { label: '1:1 Square', value: '1:1' },
  { label: '4:3 Standard', value: '4:3' },
];

const SORT_OPTIONS: { label: string; value: FilterState['sortBy'] }[] = [
  { label: '🔥 Trending Now', value: 'trending' },
  { label: '⬇️ Most Downloaded', value: 'downloads' },
  { label: '★ Highest Rated', value: 'rating' },
  { label: '✨ Recently Added', value: 'latest' },
  { label: '💖 Most Popular', value: 'popular' },
  { label: '🔤 Title A - Z', value: 'title' },
];

const COLOR_PALETTES = [
  { label: 'All Colors', value: 'All', hex: 'transparent' },
  { label: 'Dark / Black', value: 'dark', hex: '#0B0C10' },
  { label: 'Neon Blue', value: 'blue', hex: '#3B82F6' },
  { label: 'Cyber Violet', value: 'purple', hex: '#8B5CF6' },
  { label: 'Ruby Red', value: 'red', hex: '#EF4444' },
  { label: 'Emerald Green', value: 'green', hex: '#10B981' },
  { label: 'Sunset Amber', value: 'amber', hex: '#F59E0B' },
  { label: 'Clean / Light', value: 'light', hex: '#E2E8F0' },
];

export const FilterBar: React.FC<FilterBarProps> = ({
  filters,
  onFilterChange,
  totalResults,
  layoutMode,
  onToggleLayout,
}) => {
  const [showExtendedFilters, setShowExtendedFilters] = useState(false);

  const activeFiltersCount =
    (filters.resolutionCategory !== 'All' ? 1 : 0) +
    (filters.aspectRatio !== 'All' ? 1 : 0) +
    (filters.color !== 'All' ? 1 : 0) +
    (filters.sortBy !== 'trending' ? 1 : 0);

  const resetFilters = () => {
    onFilterChange({
      ...filters,
      resolutionCategory: 'All',
      aspectRatio: 'All',
      color: 'All',
      sortBy: 'trending',
    });
  };

  return (
    <div className="w-full space-y-3">
      {/* Top Bar: Results count, quick toggles, sort, and Filter button */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-2xl bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800">
        {/* Left: Results count & active tags */}
        <div className="flex items-center gap-2">
          <span className="text-xs sm:text-sm font-semibold text-zinc-800 dark:text-zinc-200">
            {totalResults} {totalResults === 1 ? 'Wallpaper' : 'Wallpapers'}
          </span>

          {activeFiltersCount > 0 && (
            <button
              onClick={resetFilters}
              className="text-xs text-rose-500 hover:text-rose-600 dark:text-rose-400 font-medium flex items-center gap-1 ml-2 px-2 py-0.5 rounded-md hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
            >
              <X className="w-3 h-3" />
              Reset filters ({activeFiltersCount})
            </button>
          )}
        </div>

        {/* Right: Quick Controls */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Quick Resolution selector */}
          <div className="relative">
            <select
              value={filters.resolutionCategory}
              onChange={(e) =>
                onFilterChange({
                  ...filters,
                  resolutionCategory: e.target.value as ResolutionCategory,
                })
              }
              className="text-xs font-semibold px-3 py-1.5 rounded-xl bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-800 dark:text-zinc-200 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              {RESOLUTIONS.map((res) => (
                <option key={res.value} value={res.value}>
                  {res.label}
                </option>
              ))}
            </select>
          </div>

          {/* Quick Sort selector */}
          <div className="relative">
            <select
              value={filters.sortBy}
              onChange={(e) =>
                onFilterChange({
                  ...filters,
                  sortBy: e.target.value as FilterState['sortBy'],
                })
              }
              className="text-xs font-semibold px-3 py-1.5 rounded-xl bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-800 dark:text-zinc-200 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              {SORT_OPTIONS.map((sort) => (
                <option key={sort.value} value={sort.value}>
                  {sort.label}
                </option>
              ))}
            </select>
          </div>

          {/* Toggle More Filters Drawer */}
          <button
            onClick={() => setShowExtendedFilters(!showExtendedFilters)}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl border transition-colors flex items-center gap-1.5 ${
              showExtendedFilters || activeFiltersCount > 0
                ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-300 dark:border-indigo-800 text-indigo-600 dark:text-indigo-400'
                : 'bg-white dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-700'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Filters</span>
            {activeFiltersCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-indigo-600 text-white text-[10px] flex items-center justify-center font-bold">
                {activeFiltersCount}
              </span>
            )}
          </button>

          {/* Layout density toggle */}
          <div className="hidden sm:flex items-center rounded-xl bg-zinc-200/70 dark:bg-zinc-800 p-0.5">
            <button
              onClick={() => onToggleLayout('standard')}
              className={`p-1.5 rounded-lg text-xs transition-colors ${
                layoutMode === 'standard'
                  ? 'bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white shadow-xs'
                  : 'text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300'
              }`}
              title="Standard Masonry Grid"
            >
              <LayoutGrid className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onToggleLayout('compact')}
              className={`p-1.5 rounded-lg text-xs transition-colors ${
                layoutMode === 'compact'
                  ? 'bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white shadow-xs'
                  : 'text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300'
              }`}
              title="Compact Dense Grid"
            >
              <Grid className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Extended Filters Drawer */}
      {showExtendedFilters && (
        <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-lg animate-in fade-in slide-in-from-top-2 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {/* Aspect Ratio Filter */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 block mb-2">
                Aspect Ratio / Device
              </label>
              <div className="flex flex-wrap gap-1.5">
                {ASPECT_RATIOS.map((ratio) => {
                  const isSelected = filters.aspectRatio === ratio.value;
                  return (
                    <button
                      key={ratio.value}
                      onClick={() => onFilterChange({ ...filters, aspectRatio: ratio.value })}
                      className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-all ${
                        isSelected
                          ? 'bg-indigo-600 text-white font-semibold shadow-xs'
                          : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-700'
                      }`}
                    >
                      {ratio.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Color Palette Filter */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 block mb-2">
                Color Tone
              </label>
              <div className="flex flex-wrap items-center gap-2">
                {COLOR_PALETTES.map((color) => {
                  const isSelected = filters.color === color.value;
                  return (
                    <button
                      key={color.value}
                      onClick={() => onFilterChange({ ...filters, color: color.value })}
                      className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                        isSelected
                          ? 'bg-indigo-600 text-white font-semibold ring-2 ring-indigo-500/40'
                          : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-700'
                      }`}
                    >
                      {color.value !== 'All' && (
                        <span
                          className="w-3 h-3 rounded-full border border-black/20 shrink-0 shadow-2xs"
                          style={{ backgroundColor: color.hex }}
                        />
                      )}
                      <span>{color.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Quick Presets */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 block mb-2">
                Display Mode
              </label>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() =>
                    onFilterChange({
                      ...filters,
                      resolutionCategory: '4K UHD',
                      aspectRatio: '16:9',
                    })
                  }
                  className="px-3 py-1.5 rounded-lg text-xs bg-zinc-100 dark:bg-zinc-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 text-zinc-700 dark:text-zinc-300 flex items-center gap-1.5"
                >
                  <Monitor className="w-3.5 h-3.5 text-indigo-500" />
                  <span>Desktop 4K</span>
                </button>

                <button
                  onClick={() =>
                    onFilterChange({
                      ...filters,
                      resolutionCategory: 'Mobile',
                      aspectRatio: '9:16',
                    })
                  }
                  className="px-3 py-1.5 rounded-lg text-xs bg-zinc-100 dark:bg-zinc-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 text-zinc-700 dark:text-zinc-300 flex items-center gap-1.5"
                >
                  <Smartphone className="w-3.5 h-3.5 text-indigo-500" />
                  <span>Smartphone 9:16</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
