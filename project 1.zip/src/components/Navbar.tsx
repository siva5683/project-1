import React, { useState } from 'react';
import {
  Sparkles,
  Heart,
  Search,
  Moon,
  Sun,
  ShieldCheck,
  User as UserIcon,
  LogOut,
  Compass,
  Layers,
  Flame,
  Check,
} from 'lucide-react';
import { User } from '../types';

interface NavbarProps {
  currentTab: 'home' | 'categories' | 'favorites' | 'admin' | 'ai-studio';
  onSelectTab: (tab: 'home' | 'categories' | 'favorites' | 'admin' | 'ai-studio') => void;
  favoritesCount: number;
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
  user: User | null;
  onOpenAuth: () => void;
  onOpenProfile: () => void;
  onOpenAIStudio: () => void;
  onLogout: () => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onSelectQuickCategory?: (cat: string) => void;
  onSwitchUserRole?: (role: 'user' | 'admin') => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  favoritesCount,
  theme,
  onToggleTheme,
  user,
  onOpenAuth,
  onOpenProfile,
  onOpenAIStudio,
  onLogout,
  searchQuery,
  onSearchChange,
  onSwitchUserRole,
}) => {
  const [showUserDropdown, setShowUserDropdown] = useState(false);
  const [searchFocused, setSearchFocused] = useState(false);

  const quickSearchSuggestions = [
    'Cyberpunk',
    'Mountains',
    'Anime Sunset',
    'Space Nebula',
    'Supercar',
    '4K Minimal',
  ];

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-xl bg-white/80 dark:bg-zinc-950/80 border-b border-zinc-200/80 dark:border-zinc-800/80 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Brand Logo */}
        <div className="flex items-center gap-6">
          <button
            onClick={() => onSelectTab('home')}
            className="flex items-center gap-2.5 group text-left focus:outline-none"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-violet-600 to-fuchsia-500 flex items-center justify-center shadow-lg shadow-indigo-500/25 group-hover:scale-105 transition-transform">
              <span className="text-white font-black tracking-wider text-lg">L</span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-zinc-900 via-zinc-800 to-zinc-700 dark:from-white dark:via-zinc-100 dark:to-zinc-300 bg-clip-text text-transparent">
                  LUMINA
                </span>
                <span className="text-[10px] uppercase font-bold tracking-widest px-1.5 py-0.5 rounded bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20">
                  4K UHD
                </span>
              </div>
              <p className="text-[10px] text-zinc-500 dark:text-zinc-400 font-medium tracking-wide">
                Ultra HD & AI Wallpapers
              </p>
            </div>
          </button>

          {/* Desktop Nav Links */}
          <nav className="hidden md:flex items-center gap-1 ml-2">
            <button
              onClick={() => onSelectTab('home')}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
                currentTab === 'home'
                  ? 'bg-zinc-100 dark:bg-zinc-800/90 text-zinc-900 dark:text-white font-semibold'
                  : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white hover:bg-zinc-100/60 dark:hover:bg-zinc-800/50'
              }`}
            >
              <Compass className="w-4 h-4" />
              Explore
            </button>

            <button
              onClick={() => onSelectTab('categories')}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
                currentTab === 'categories'
                  ? 'bg-zinc-100 dark:bg-zinc-800/90 text-zinc-900 dark:text-white font-semibold'
                  : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white hover:bg-zinc-100/60 dark:hover:bg-zinc-800/50'
              }`}
            >
              <Layers className="w-4 h-4" />
              Categories
            </button>

            <button
              onClick={() => onSelectTab('ai-studio')}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-1.5 relative ${
                currentTab === 'ai-studio'
                  ? 'bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow-md shadow-violet-500/25'
                  : 'text-violet-600 dark:text-violet-400 hover:bg-violet-50 dark:hover:bg-violet-950/40'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>AI Studio</span>
              <span className="text-[9px] uppercase tracking-wider font-extrabold px-1 py-0.2 rounded bg-amber-400/20 text-amber-500 border border-amber-400/30">
                PRO
              </span>
            </button>

            <button
              onClick={() => onSelectTab('favorites')}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
                currentTab === 'favorites'
                  ? 'bg-zinc-100 dark:bg-zinc-800/90 text-zinc-900 dark:text-white font-semibold'
                  : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white hover:bg-zinc-100/60 dark:hover:bg-zinc-800/50'
              }`}
            >
              <Heart className={`w-4 h-4 ${favoritesCount > 0 ? 'text-rose-500 fill-rose-500' : ''}`} />
              <span>Favorites</span>
              {favoritesCount > 0 && (
                <span className="text-xs px-1.5 py-0.2 rounded-full bg-rose-500/10 text-rose-500 dark:text-rose-400 font-bold border border-rose-500/20">
                  {favoritesCount}
                </span>
              )}
            </button>

            {user?.role === 'admin' && (
              <button
                onClick={() => onSelectTab('admin')}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
                  currentTab === 'admin'
                    ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 font-semibold'
                    : 'text-zinc-600 dark:text-zinc-400 hover:text-emerald-600 dark:hover:text-emerald-400 hover:bg-zinc-100/60 dark:hover:bg-zinc-800/50'
                }`}
              >
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                Admin
              </button>
            )}
          </nav>
        </div>

        {/* Search Bar - Center/Right */}
        <div className="flex-1 max-w-xs sm:max-w-sm lg:max-w-md relative hidden sm:block">
          <div className="relative">
            <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              placeholder="Search 4K wallpapers, anime, cars, space..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              onFocus={() => setSearchFocused(true)}
              onBlur={() => setTimeout(() => setSearchFocused(false), 200)}
              className="w-full pl-10 pr-4 py-2 text-sm rounded-xl bg-zinc-100/80 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-zinc-400 hover:text-zinc-200"
              >
                Clear
              </button>
            )}
          </div>

          {/* Quick Search dropdown when focused and empty */}
          {searchFocused && !searchQuery && (
            <div className="absolute top-full left-0 right-0 mt-1.5 p-3 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-xl z-50 animate-in fade-in slide-in-from-top-2">
              <div className="flex items-center gap-1.5 text-xs text-zinc-400 mb-2">
                <Flame className="w-3.5 h-3.5 text-amber-500" />
                <span className="font-semibold uppercase tracking-wider text-[10px]">Popular Searches</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {quickSearchSuggestions.map((term) => (
                  <button
                    key={term}
                    onMouseDown={() => onSearchChange(term)}
                    className="px-2.5 py-1 text-xs rounded-lg bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                  >
                    {term}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Actions: AI Studio button, Theme Toggle, Auth / User Menu */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Quick AI Generator trigger button on mobile */}
          <button
            onClick={onOpenAIStudio}
            className="md:hidden p-2 rounded-xl text-violet-600 dark:text-violet-400 bg-violet-50 dark:bg-violet-950/50 border border-violet-500/20"
            title="AI Wallpaper Studio"
          >
            <Sparkles className="w-4 h-4" />
          </button>

          {/* Theme Toggle */}
          <button
            onClick={onToggleTheme}
            className="p-2 rounded-xl text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white hover:bg-zinc-100 dark:hover:bg-zinc-800/80 transition-colors focus:outline-none"
            aria-label="Toggle Theme"
            title={`Switch to ${theme === 'dark' ? 'Light' : 'Dark'} mode`}
          >
            {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* User Auth / Profile Dropdown */}
          {user ? (
            <div className="relative">
              <button
                onClick={() => setShowUserDropdown(!showUserDropdown)}
                className="flex items-center gap-2 p-1 pl-2 pr-1 rounded-full border border-zinc-200 dark:border-zinc-800 hover:border-zinc-300 dark:hover:border-zinc-700 transition-colors bg-zinc-50 dark:bg-zinc-900"
              >
                <span className="text-xs font-semibold text-zinc-700 dark:text-zinc-300 max-w-[80px] truncate hidden sm:inline">
                  {user.name}
                </span>
                <img
                  src={user.avatar}
                  alt={user.name}
                  className="w-7 h-7 rounded-full object-cover ring-2 ring-indigo-500/30"
                />
              </button>

              {showUserDropdown && (
                <div
                  onMouseLeave={() => setShowUserDropdown(false)}
                  className="absolute right-0 mt-2 w-64 p-2 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-2xl z-50 animate-in fade-in slide-in-from-top-2"
                >
                  <div className="p-3 border-b border-zinc-100 dark:border-zinc-800 flex items-center gap-3">
                    <img
                      src={user.avatar}
                      alt={user.name}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div className="overflow-hidden">
                      <p className="text-sm font-bold text-zinc-900 dark:text-zinc-100 truncate">
                        {user.name}
                      </p>
                      <p className="text-xs text-zinc-500 dark:text-zinc-400 truncate">
                        {user.email}
                      </p>
                      <span className="inline-block mt-1 text-[10px] uppercase font-bold px-1.5 py-0.2 rounded bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20">
                        {user.role}
                      </span>
                    </div>
                  </div>

                  <div className="py-1">
                    <button
                      onClick={() => {
                        setShowUserDropdown(false);
                        onOpenProfile();
                      }}
                      className="w-full px-3 py-2 text-left text-sm rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300 flex items-center gap-2"
                    >
                      <UserIcon className="w-4 h-4 text-zinc-400" />
                      View Profile & Activity
                    </button>

                    <button
                      onClick={() => {
                        setShowUserDropdown(false);
                        onSelectTab('favorites');
                      }}
                      className="w-full px-3 py-2 text-left text-sm rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300 flex items-center gap-2"
                    >
                      <Heart className="w-4 h-4 text-rose-500" />
                      My Favorites ({favoritesCount})
                    </button>

                    {/* Quick switch between Member and Admin */}
                    {onSwitchUserRole && (
                      <div className="my-1 pt-1 border-t border-zinc-100 dark:border-zinc-800">
                        <p className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-zinc-400">
                          Switch Role (Demo)
                        </p>
                        <button
                          onClick={() => {
                            onSwitchUserRole(user.role === 'admin' ? 'user' : 'admin');
                            setShowUserDropdown(false);
                          }}
                          className="w-full px-3 py-1.5 text-left text-xs rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-400 flex items-center justify-between"
                        >
                          <span>Switch to {user.role === 'admin' ? 'Regular User' : 'Admin Curator'}</span>
                          <Check className="w-3.5 h-3.5 text-indigo-500" />
                        </button>
                      </div>
                    )}

                    {user.role === 'admin' && (
                      <button
                        onClick={() => {
                          setShowUserDropdown(false);
                          onSelectTab('admin');
                        }}
                        className="w-full px-3 py-2 text-left text-sm rounded-lg hover:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center gap-2"
                      >
                        <ShieldCheck className="w-4 h-4" />
                        Admin Dashboard
                      </button>
                    )}
                  </div>

                  <div className="pt-1 border-t border-zinc-100 dark:border-zinc-800">
                    <button
                      onClick={() => {
                        setShowUserDropdown(false);
                        onLogout();
                      }}
                      className="w-full px-3 py-2 text-left text-sm rounded-lg hover:bg-rose-500/10 text-rose-600 dark:text-rose-400 flex items-center gap-2"
                    >
                      <LogOut className="w-4 h-4" />
                      Sign Out
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              className="px-4 py-1.5 text-sm font-semibold rounded-xl bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 hover:bg-zinc-800 dark:hover:bg-zinc-100 transition-colors shadow-sm"
            >
              Sign In
            </button>
          )}
        </div>
      </div>

      {/* Mobile search bar */}
      <div className="sm:hidden px-4 pb-3">
        <div className="relative">
          <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            placeholder="Search 4K wallpapers..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full pl-9 pr-4 py-1.5 text-sm rounded-xl bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* Mobile Bottom Navigation Bar */}
      <div className="md:hidden flex items-center justify-around py-2 border-t border-zinc-200 dark:border-zinc-800 bg-white/90 dark:bg-zinc-950/90 text-xs font-medium">
        <button
          onClick={() => onSelectTab('home')}
          className={`flex flex-col items-center gap-0.5 ${currentTab === 'home' ? 'text-indigo-600 dark:text-indigo-400' : 'text-zinc-500'}`}
        >
          <Compass className="w-4 h-4" />
          <span>Home</span>
        </button>
        <button
          onClick={() => onSelectTab('categories')}
          className={`flex flex-col items-center gap-0.5 ${currentTab === 'categories' ? 'text-indigo-600 dark:text-indigo-400' : 'text-zinc-500'}`}
        >
          <Layers className="w-4 h-4" />
          <span>Categories</span>
        </button>
        <button
          onClick={() => onSelectTab('ai-studio')}
          className={`flex flex-col items-center gap-0.5 ${currentTab === 'ai-studio' ? 'text-violet-600 dark:text-violet-400' : 'text-zinc-500'}`}
        >
          <Sparkles className="w-4 h-4" />
          <span>AI Studio</span>
        </button>
        <button
          onClick={() => onSelectTab('favorites')}
          className={`flex flex-col items-center gap-0.5 relative ${currentTab === 'favorites' ? 'text-rose-500' : 'text-zinc-500'}`}
        >
          <Heart className="w-4 h-4" />
          <span>Favorites</span>
          {favoritesCount > 0 && (
            <span className="absolute -top-1 -right-2 w-4 h-4 rounded-full bg-rose-500 text-white text-[9px] flex items-center justify-center font-bold">
              {favoritesCount}
            </span>
          )}
        </button>
        {user?.role === 'admin' && (
          <button
            onClick={() => onSelectTab('admin')}
            className={`flex flex-col items-center gap-0.5 ${currentTab === 'admin' ? 'text-emerald-500' : 'text-zinc-500'}`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Admin</span>
          </button>
        )}
      </div>
    </header>
  );
};
