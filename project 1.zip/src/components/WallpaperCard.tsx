import React, { useState } from 'react';
import {
  Download,
  Heart,
  Eye,
  Star,
  Sparkles,
  Share2,
} from 'lucide-react';
import { Wallpaper } from '../types';

interface WallpaperCardProps {
  wallpaper: Wallpaper;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
  onOpenDetails: (wallpaper: Wallpaper) => void;
  onDownload: (wallpaper: Wallpaper) => void;
  onShare?: (wallpaper: Wallpaper) => void;
  layoutMode?: 'standard' | 'compact';
}

export const WallpaperCard: React.FC<WallpaperCardProps> = ({
  wallpaper,
  isFavorite,
  onToggleFavorite,
  onOpenDetails,
  onDownload,
  layoutMode = 'standard',
}) => {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const getAspectClass = () => {
    if (wallpaper.aspectRatio === '9:16') return 'aspect-[9/16]';
    if (wallpaper.aspectRatio === '21:9') return 'aspect-[21/9]';
    if (wallpaper.aspectRatio === '1:1') return 'aspect-square';
    if (wallpaper.aspectRatio === '4:3') return 'aspect-[4/3]';
    return 'aspect-[16/10] sm:aspect-[16/9]';
  };

  return (
    <div
      onClick={() => onOpenDetails(wallpaper)}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="group relative rounded-2xl overflow-hidden cursor-pointer bg-zinc-100 dark:bg-zinc-900 border border-zinc-200/90 dark:border-zinc-800/90 shadow-sm hover:shadow-2xl hover:border-indigo-500/40 dark:hover:border-indigo-500/40 transition-all duration-300 flex flex-col justify-end"
    >
      {/* Container with dynamic aspect ratio */}
      <div className={`w-full overflow-hidden relative ${getAspectClass()}`}>
        {/* Placeholder blur background */}
        <div
          className={`absolute inset-0 bg-zinc-200 dark:bg-zinc-850 transition-opacity duration-500 ${
            imageLoaded ? 'opacity-0 pointer-events-none' : 'opacity-100 animate-pulse'
          }`}
        />

        {/* Thumbnail Image */}
        <img
          src={wallpaper.thumbnailUrl || wallpaper.imageUrl}
          alt={wallpaper.title}
          loading="lazy"
          onLoad={() => setImageLoaded(true)}
          className={`w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105 ${
            imageLoaded ? 'opacity-100' : 'opacity-0'
          }`}
        />

        {/* Ambient Top & Bottom Gradients for high contrast text readability */}
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/90 via-zinc-950/20 to-zinc-950/40 opacity-70 group-hover:opacity-90 transition-opacity" />

        {/* Top Badges & Favorite Heart */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-auto">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="px-2 py-0.5 rounded-lg text-[11px] font-bold bg-black/60 backdrop-blur-md text-white border border-white/10 shadow-xs">
              {wallpaper.resolutionCategory === '4K UHD' ? '4K UHD' : wallpaper.resolutionCategory}
            </span>

            {wallpaper.isAiGenerated && (
              <span className="px-2 py-0.5 rounded-lg text-[10px] font-extrabold bg-violet-600/80 backdrop-blur-md text-white border border-violet-400/30 flex items-center gap-1 shadow-xs">
                <Sparkles className="w-2.5 h-2.5 text-amber-300" />
                AI
              </span>
            )}
          </div>

          {/* Favorite button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              onToggleFavorite(wallpaper.id);
            }}
            className={`p-2 rounded-full backdrop-blur-md transition-all duration-200 active:scale-90 ${
              isFavorite
                ? 'bg-rose-500 text-white shadow-md shadow-rose-500/30'
                : 'bg-black/40 text-white/80 hover:text-white hover:bg-black/70 hover:scale-110'
            }`}
            aria-label="Add to favorites"
          >
            <Heart className={`w-3.5 h-3.5 ${isFavorite ? 'fill-current' : ''}`} />
          </button>
        </div>

        {/* Bottom Details & Quick Download */}
        <div className="absolute bottom-0 left-0 right-0 p-3.5 text-white flex flex-col justify-end">
          {/* Category & Rating */}
          <div className="flex items-center justify-between text-xs text-zinc-300 mb-1">
            <span className="font-semibold text-indigo-300 tracking-wide text-[11px] uppercase">
              {wallpaper.category}
            </span>
            <div className="flex items-center gap-1 font-semibold text-[11px] text-amber-400">
              <Star className="w-3 h-3 fill-current" />
              <span>{wallpaper.rating}</span>
            </div>
          </div>

          {/* Title */}
          <h4 className="text-sm sm:text-base font-bold text-white tracking-tight line-clamp-1 drop-shadow-sm group-hover:text-indigo-200 transition-colors">
            {wallpaper.title}
          </h4>

          {/* Action Row */}
          <div className="mt-2.5 pt-2 border-t border-white/10 flex items-center justify-between gap-2">
            <div className="text-[11px] text-zinc-300 font-medium">
              <span>{wallpaper.downloads.toLocaleString()} downloads</span>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDownload(wallpaper);
                }}
                className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-md shadow-indigo-600/30 flex items-center gap-1 transition-all active:scale-95"
                title="Direct Download"
              >
                <Download className="w-3 h-3" />
                <span className="hidden sm:inline">Download</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
