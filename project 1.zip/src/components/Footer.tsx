import React, { useState } from 'react';
import { Sparkles, Heart, Mail, Check, ArrowRight } from 'lucide-react';

interface FooterProps {
  onOpenModal: (type: 'about' | 'contact' | 'privacy' | 'terms') => void;
  onSelectCategory: (category: string) => void;
  onSelectResolution: (res: string) => void;
  onOpenAIStudio: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onOpenModal,
  onSelectCategory,
  onSelectResolution,
  onOpenAIStudio,
}) => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail) {
      setSubscribed(true);
      setNewsletterEmail('');
      setTimeout(() => setSubscribed(false), 4000);
    }
  };

  const topCategories = ['Nature', 'Cars', 'Anime', 'Space', 'Gaming', 'Technology', 'Abstract'];
  const popularResolutions = ['4K UHD', '2K QHD', '1080p FHD', 'Ultrawide', 'Mobile'];

  return (
    <footer className="w-full bg-zinc-100 dark:bg-zinc-950 border-t border-zinc-200 dark:border-zinc-800/80 transition-colors mt-16 pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 pb-12 border-b border-zinc-200 dark:border-zinc-800">
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-600 flex items-center justify-center text-white font-black text-sm shadow-md">
                L
              </div>
              <span className="font-extrabold text-lg tracking-tight text-zinc-900 dark:text-white">
                LUMINA
              </span>
              <span className="text-[10px] uppercase font-bold tracking-widest px-1.5 py-0.5 rounded bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20">
                4K UHD
              </span>
            </div>

            <p className="text-xs sm:text-sm text-zinc-600 dark:text-zinc-400 max-w-sm leading-relaxed">
              Curating stunning 4K and Ultra HD wallpapers for desktops, laptops, phones, and ultrawide setups. Empowering imagination with Gemini 3 Pro AI.
            </p>

            {/* Newsletter */}
            <div className="pt-2">
              <p className="text-xs font-bold text-zinc-900 dark:text-white mb-2">
                Join Lumina Wallpaper Digest
              </p>
              <form onSubmit={handleSubscribe} className="flex gap-2 max-w-sm">
                <input
                  type="email"
                  required
                  placeholder="Enter your email"
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  className="flex-1 px-3 py-2 text-xs rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1 shrink-0 transition-colors"
                >
                  {subscribed ? <Check className="w-3.5 h-3.5" /> : <span>Subscribe</span>}
                </button>
              </form>
              {subscribed && (
                <p className="text-[11px] text-emerald-500 font-semibold mt-1">
                  Subscribed! You will receive weekly 4K drops.
                </p>
              )}
            </div>
          </div>

          {/* Categories Col */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-900 dark:text-white mb-3">
              Categories
            </h4>
            <ul className="space-y-2 text-xs text-zinc-600 dark:text-zinc-400">
              {topCategories.map((cat) => (
                <li key={cat}>
                  <button
                    onClick={() => onSelectCategory(cat)}
                    className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-left"
                  >
                    {cat} Wallpapers
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Resolutions Col */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-900 dark:text-white mb-3">
              Resolutions
            </h4>
            <ul className="space-y-2 text-xs text-zinc-600 dark:text-zinc-400">
              {popularResolutions.map((res) => (
                <li key={res}>
                  <button
                    onClick={() => onSelectResolution(res)}
                    className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-left"
                  >
                    {res} Wallpapers
                  </button>
                </li>
              ))}
              <li>
                <button
                  onClick={onOpenAIStudio}
                  className="text-violet-600 dark:text-violet-400 font-semibold flex items-center gap-1 hover:underline pt-1"
                >
                  <Sparkles className="w-3 h-3" />
                  <span>AI Studio Studio</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Legal & Info Col */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-900 dark:text-white mb-3">
              Platform & Legal
            </h4>
            <ul className="space-y-2 text-xs text-zinc-600 dark:text-zinc-400">
              <li>
                <button
                  onClick={() => onOpenModal('about')}
                  className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                >
                  About Lumina
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenModal('contact')}
                  className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                >
                  Contact Support
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenModal('privacy')}
                  className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                >
                  Privacy Policy
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenModal('terms')}
                  className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                >
                  Terms of Service
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom copyright row */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-zinc-500">
          <p>© {new Date().getFullYear()} Lumina Wallpapers. All rights reserved.</p>
          <p className="flex items-center gap-1">
            Built for screen perfectionists with high-density 4K standards.
          </p>
        </div>
      </div>
    </footer>
  );
};
