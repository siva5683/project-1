import React from 'react';
import {
  Trees,
  Rocket,
  Sparkles,
  Car,
  Cpu,
  Cat,
  Trophy,
  Boxes,
  Gamepad2,
  Building2,
  Wand2,
  Folder,
  ArrowRight,
} from 'lucide-react';
import { Category } from '../types';

interface CategoryChipsProps {
  categories: Category[];
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
  variant?: 'chips' | 'grid';
}

const ICON_MAP: Record<string, React.ReactNode> = {
  Trees: <Trees className="w-4 h-4" />,
  Rocket: <Rocket className="w-4 h-4" />,
  Sparkles: <Sparkles className="w-4 h-4" />,
  Car: <Car className="w-4 h-4" />,
  Cpu: <Cpu className="w-4 h-4" />,
  Cat: <Cat className="w-4 h-4" />,
  Trophy: <Trophy className="w-4 h-4" />,
  Boxes: <Boxes className="w-4 h-4" />,
  Gamepad2: <Gamepad2 className="w-4 h-4" />,
  Building2: <Building2 className="w-4 h-4" />,
  Wand2: <Wand2 className="w-4 h-4" />,
};

export const CategoryChips: React.FC<CategoryChipsProps> = ({
  categories,
  selectedCategory,
  onSelectCategory,
  variant = 'chips',
}) => {
  if (variant === 'grid') {
    return (
      <div className="py-8">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs uppercase font-bold tracking-widest text-indigo-600 dark:text-indigo-400 px-3 py-1 rounded-full bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800">
            Collections
          </span>
          <h2 className="mt-3 text-3xl sm:text-4xl font-black text-zinc-900 dark:text-white tracking-tight">
            Browse By Category
          </h2>
          <p className="mt-2 text-sm sm:text-base text-zinc-600 dark:text-zinc-400">
            Hand-curated collections of high-resolution 4K and 2K wallpapers. Choose a world that matches your vibe.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {categories.map((cat) => {
            const isSelected = selectedCategory.toLowerCase() === cat.name.toLowerCase();
            return (
              <div
                key={cat.id}
                onClick={() => onSelectCategory(cat.name)}
                className={`group relative rounded-3xl overflow-hidden aspect-[4/3] cursor-pointer shadow-md hover:shadow-xl transition-all duration-300 border ${
                  isSelected
                    ? 'ring-4 ring-indigo-500 border-indigo-500 scale-[1.02]'
                    : 'border-zinc-200 dark:border-zinc-800 hover:border-indigo-500/50 hover:scale-[1.02]'
                }`}
              >
                <img
                  src={cat.coverImage}
                  alt={cat.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/90 via-zinc-950/40 to-transparent" />

                <div className="absolute top-4 right-4">
                  <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-black/60 backdrop-blur-md text-white border border-white/10">
                    {cat.count} Wallpapers
                  </span>
                </div>

                <div className="absolute bottom-4 left-4 right-4 text-white">
                  <div className="flex items-center gap-2 mb-1.5 text-indigo-400">
                    {ICON_MAP[cat.iconName] || <Folder className="w-4 h-4" />}
                    <span className="text-xs uppercase tracking-wider font-extrabold">
                      {cat.name}
                    </span>
                  </div>
                  <h3 className="text-lg font-bold tracking-tight text-white group-hover:text-indigo-300 transition-colors">
                    {cat.name}
                  </h3>
                  <p className="mt-1 text-xs text-zinc-300 line-clamp-2 leading-relaxed">
                    {cat.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  // Chips format (for Gallery & Home page quick filter)
  return (
    <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none py-1">
      {/* "All" button */}
      <button
        onClick={() => onSelectCategory('All')}
        className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all shrink-0 flex items-center gap-2 ${
          selectedCategory === 'All'
            ? 'bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 shadow-md shadow-zinc-900/10'
            : 'bg-zinc-100 dark:bg-zinc-850 hover:bg-zinc-200 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-800'
        }`}
      >
        <span>All Wallpapers</span>
      </button>

      {categories.map((cat) => {
        const isSelected = selectedCategory.toLowerCase() === cat.name.toLowerCase();
        return (
          <button
            key={cat.id}
            onClick={() => onSelectCategory(cat.name)}
            className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all shrink-0 flex items-center gap-2 ${
              isSelected
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/25 ring-2 ring-indigo-500/30'
                : 'bg-zinc-100 dark:bg-zinc-850 hover:bg-zinc-200 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-800'
            }`}
          >
            <span className={isSelected ? 'text-white' : 'text-zinc-500 dark:text-zinc-400'}>
              {ICON_MAP[cat.iconName] || <Folder className="w-3.5 h-3.5" />}
            </span>
            <span>{cat.name}</span>
            <span
              className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                isSelected
                  ? 'bg-white/20 text-white'
                  : 'bg-zinc-200 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400'
              }`}
            >
              {cat.count}
            </span>
          </button>
        );
      })}
    </div>
  );
};
