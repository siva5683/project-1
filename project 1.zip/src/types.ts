export type AspectRatio =
  | '1:1'
  | '2:3'
  | '3:2'
  | '3:4'
  | '4:3'
  | '9:16'
  | '16:9'
  | '21:9';

export type ImageSize = '1K' | '2K' | '4K';

export type ResolutionCategory =
  | 'All'
  | '4K UHD'
  | '2K QHD'
  | '1080p FHD'
  | 'Ultrawide'
  | 'Mobile';

export interface Wallpaper {
  id: string;
  title: string;
  category: string;
  resolution: string; // e.g., '3840 x 2160 (4K)'
  resolutionCategory: ResolutionCategory;
  aspectRatio: AspectRatio;
  fileSize: string; // e.g., '6.8 MB'
  imageUrl: string;
  thumbnailUrl: string;
  downloads: number;
  likes: number;
  views: number;
  rating: number; // 1-5 scale, e.g., 4.9
  ratingsCount: number;
  tags: string[];
  palette: string[]; // hex codes e.g. ['#1A202C', '#3182CE']
  author: {
    name: string;
    handle: string;
    avatar: string;
  };
  createdAt: string;
  isFeatured?: boolean;
  isTrending?: boolean;
  isLatest?: boolean;
  isPopular?: boolean;
  isAiGenerated?: boolean;
  aiPrompt?: string;
  aiModel?: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  iconName: string;
  coverImage: string;
  count: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role: 'user' | 'admin';
  bio?: string;
  joinedAt: string;
  favoriteIds: string[];
  downloadsCount: number;
  generatedCount: number;
}

export interface WallpaperReport {
  id: string;
  wallpaperId: string;
  wallpaperTitle: string;
  reason: 'copyright' | 'inappropriate' | 'low_quality' | 'broken' | 'other';
  comment: string;
  reportedAt: string;
  status: 'pending' | 'resolved' | 'dismissed';
}

export interface FilterState {
  searchQuery: string;
  category: string;
  resolutionCategory: ResolutionCategory;
  aspectRatio: string; // 'All' or specific ratio
  sortBy: 'trending' | 'popular' | 'latest' | 'rating' | 'downloads' | 'title';
  color: string; // 'All' or hex string
}
