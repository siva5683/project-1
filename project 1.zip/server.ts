import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const isProd = process.env.NODE_ENV === 'production';
const PORT = Number(process.env.PORT) || 3000;

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '20mb' }));

  // Initialize Gemini client (User-Agent header required by AI Studio guidelines)
  const apiKey = process.env.GEMINI_API_KEY || '';
  let ai: GoogleGenAI | null = null;
  if (apiKey) {
    try {
      ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });
    } catch (err) {
      console.error('Failed to instantiate GoogleGenAI:', err);
    }
  }

  // API Route: Generate AI Wallpaper
  app.post('/api/generate-wallpaper', async (req: Request, res: Response) => {
    try {
      const {
        prompt,
        model = 'gemini-3-pro-image-preview',
        imageSize = '2K',
        aspectRatio = '16:9',
      } = req.body;

      if (!prompt || typeof prompt !== 'string') {
        res.status(400).json({ error: 'Prompt is required.' });
        return;
      }

      if (!ai || !apiKey) {
        res.status(503).json({
          error: 'GEMINI_API_KEY is not configured on the server. Please check your environment variables.',
        });
        return;
      }

      // Allowed Gemini aspect ratios: '1:1', '3:4', '4:3', '9:16', '16:9', '21:9', etc.
      // Note: Map 2:3 and 3:2 to 3:4 and 4:3 if unsupported, or pass through
      let mappedAspectRatio = aspectRatio;
      const validAspectRatios = ['1:1', '2:3', '3:2', '3:4', '4:3', '9:16', '16:9', '21:9'];
      if (!validAspectRatios.includes(mappedAspectRatio)) {
        mappedAspectRatio = '16:9';
      }

      // Models allowed: gemini-3-pro-image-preview, gemini-3.1-flash-image-preview
      const targetModel =
        model === 'gemini-3.1-flash-image-preview'
          ? 'gemini-3.1-flash-image-preview'
          : 'gemini-3-pro-image-preview';

      // Supported sizes: 1K, 2K, 4K
      const targetSize = ['1K', '2K', '4K'].includes(imageSize) ? imageSize : '1K';

      // If aspect ratio is 21:9 or 2:3/3:2, map to the closest official ratio if the model requires
      let apiAspectRatio = mappedAspectRatio;
      if (mappedAspectRatio === '21:9') {
        // Nano banana models strictly accept 1:1, 3:4, 4:3, 9:16, 16:9 (plus 1:4, 1:8, 4:1, 8:1 for pro/flash)
        apiAspectRatio = '16:9';
      } else if (mappedAspectRatio === '2:3') {
        apiAspectRatio = '3:4';
      } else if (mappedAspectRatio === '3:2') {
        apiAspectRatio = '4:3';
      }

      const response = await ai.models.generateContent({
        model: targetModel,
        contents: {
          parts: [
            {
              text: `${prompt}. Ultra-high resolution, stunning composition, masterpiece wallpaper, sharp focus, vivid colors, wallpaper quality.`,
            },
          ],
        },
        config: {
          imageConfig: {
            aspectRatio: apiAspectRatio as any,
            imageSize: targetSize as any,
          },
        },
      });

      let imageUrl: string | null = null;
      let textInfo = '';

      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            imageUrl = `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
            break;
          } else if (part.text) {
            textInfo += part.text;
          }
        }
      }

      if (!imageUrl) {
        res.status(500).json({
          error: 'Model did not return image data.',
          details: textInfo || 'No parts returned.',
        });
        return;
      }

      res.json({
        success: true,
        imageUrl,
        aspectRatio,
        imageSize: targetSize,
        model: targetModel,
        prompt,
      });
    } catch (error: any) {
      console.error('Error generating wallpaper:', error);
      res.status(500).json({
        error: error?.message || 'Failed to generate wallpaper with Gemini.',
      });
    }
  });

  // API Route: Prompt enhancement
  app.post('/api/enhance-prompt', async (req: Request, res: Response) => {
    try {
      const { prompt } = req.body;
      if (!prompt) {
        res.status(400).json({ error: 'Prompt is required.' });
        return;
      }
      if (!ai || !apiKey) {
        res.json({
          enhancedPrompt: `${prompt}, 8k UHD wallpaper, volumetric lighting, photorealistic, cinematic atmosphere, award-winning composition`,
        });
        return;
      }

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `Transform this wallpaper idea into a vivid, descriptive prompt for an ultra high-quality wallpaper generator. Keep it concise (1-2 sentences) and focus on lighting, texture, atmosphere, and visual details. Do not use quotes.
Idea: "${prompt}"`,
      });

      res.json({
        enhancedPrompt: response.text?.trim() || prompt,
      });
    } catch (err: any) {
      console.error('Prompt enhancement failed:', err);
      res.json({
        enhancedPrompt: `${req.body.prompt}, 8k UHD wallpaper, atmospheric lighting, vibrant colors, stunning detail`,
      });
    }
  });

  // Vite middleware in dev or static files in production
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Lumina Wallpaper server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
